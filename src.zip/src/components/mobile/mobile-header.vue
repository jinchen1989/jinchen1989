<template>
  <div class="mobile-header">1111</div>
</template>

<script></script>

<style lang="scss" scoped>
.mobile-header {
  width: 100%;
  height: 0.5rem;
  background-color: #000;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 1000;
}
</style>
