<template>
  <div id="legal-pay" class="bg-main clr-part" style="padding-top:100px;">
    
    <!-- <div class="my-user" data-v-68c6c4ce="" data-v-4dbd84e4="">
      <div class="myInfo">
        <div class="my_img">
          <img src="../assets/images/per_head.png">
        </div>
        <div class="userName">{{ sellInfo.name }}</div>
      </div>
      <div class="userInfo">
        <div class="userList">
          <div class="label">总成单</div>
          <div class="item">{{ sellInfo.total }}</div>
        </div>
        <div class="userList">
          <div class="label">30日成单</div>
          <div class="item">{{ sellInfo.thirty_days }}</div>
        </div>
        <div class="userList">
          <div class="label">完成单</div>
          <div class="item">{{ sellInfo.done }}</div>
        </div>
        <div class="userList">
          <div class="label">30日成单率</div>
          <div class="item">{{ sellInfo.percent }}</div>
        </div>
      </div>
    </div> -->
    
    <div class="title bg-part ft16 flex between alcenter">
      <span v-if="msg.status == 1&&type =='buy'">{{$t('ddh')}}:{{ msg.legal_list_id }}</span>
      <div v-if="msg.status == 3">{{$t('legal.ordercomplete')}}</div>
      <div v-if="msg.status == 4">{{$t('legal.orderceiled')}}</div>
      <div v-if="msg.status == 2&&type =='buy'">{{$t('legal.payedwait')}}</div>
      
      <span v-if="msg.status == 1 && type =='buy'">{{msg.total_price}} {{msg.money_short}}({{$t('legal.payplease')}})</span>
      <!-- <span class="ft14 curPer" @click="connect">联系对方</span> -->
    </div>

    <div class="prompt">
      <div class="tips">
        <p><span></span>{{$t('qzfz')}}</p>
        <div data-v-68c6c4ce="" data-v-b3d61668=""></div>
      </div>
    </div>
    <div class="order_detail">
      <div class="detail-top">
        <div class="detail-top-one">
          <div>
            <p class="p-title">{{$t('jyje')}}：</p>
            <h6>{{msg.total_price}}<span> {{msg.money_short}}</span></h6>
          </div>
          <div>
            <p class="p-title">{{$t('jysl')}}：</p>
            <h6>{{msg.number}}{{msg.currency_name}}</h6>
          </div>
          <div>
            <p class="p-title">{{$t('jyjg')}}：</p>
            <h6>{{msg.price}} {{msg.money_short}}</h6>
          </div>
        </div>
        <div class="detail-top-two">
          <p class="p-title">{{$t('zfxq')}}：</p>
          <p class="pay-tip">{{$t('qsybr')}}</p>
          <ul>
            <li v-for="(itm,idx) in msg.user_cashier" :key="idx">
              <div>
                <p style="max-width:240px;">{{$t('zffs')}}:&nbsp;&nbsp;{{ itm.cashier_type }}</p>
                <p v-if="itm.bank_name"> {{ itm.bank_name }} {{ itm.address }} </p>
                <p> {{ itm.name }} {{ itm.account }} </p>
                <p style="max-width:240px;word-wrap:break-word;">
                  <img class="pic" :src="itm.pic" @click="show_pic(itm.pic)">
                </p>
              </div>
            </li>
          </ul>
        </div>
        <div class="detail-top-three">
          <p class="p-title"><span></span>{{$t('zysx')}}：</p>
          <ul>
            <li>1.<span>{{$t('ndhk')}}</span></li>
            <li>2.<span>{{$t('qqrdf')}}</span></li>
            <li>3.<span>{{$t('zwpt')}}</span></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="info bg-part ft14">
      <!-- <div class="flex">
        <span>{{$t('legal.tprice')}}：</span>
        <span>{{msg.price}} {{msg.money_short}}</span>
      </div>
      <div class="flex">
        <span>{{$t('legal.tnumber')}}：</span>
        <span>{{msg.number}}{{msg.currency_name}}</span>
      </div>
      <div class="flex">
        <span>{{$t('legal.ordertime')}}：</span>
        <span>{{msg.create_time}}</span>
      </div> -->
      <!--收款方式--->
      <!-- <div class="flex" v-if="msg.status == 1||msg.status == 2&&type =='buy'">
        <span>{{$t('legal.cardnum')}}：</span>
        <span>{{msg.bank_name}}:{{msg.bank_account}}</span>
      </div>
      <div class="flex" v-if="msg.status == 1||msg.status == 2&&type =='buy'">
        <span>{{$t('legal.bankName')}}：</span>
        <span>{{msg.bank_address}}</span>
      </div>
      <div class="flex" v-if="msg.status == 1||msg.status == 2&&type =='buy'">
        <span>{{$t('legal.wechat')}}：</span>
        <span>{{msg.wechat_account}}</span>
      </div>
      <div class="flex" v-if="msg.status == 1||msg.status == 2&&type =='buy'">
        <span>{{$t('legal.alipay')}}：</span>
        <span>{{msg.alipay_account}}</span>
      </div> -->
      <!-- <div v-for="(itm,idx) in msg.user_cashier" :key="idx" style="display:block">
        <div class="flex">
          <span>{{$t('legaltrade.paytype')}}：</span>
           <span>{{itm.cashier_type}}</span>
        </div>
        <div class="flex" v-if="itm.bank_name">
          <span>{{$t('legal.bankName')}}：</span>
           <span>{{itm.bank_name}}</span>
        </div>
        <div class="flex" v-if="itm.bank_name">
          <span>{{$t('legaltrade.zhihang')}}：</span>
           <span>{{itm.address}}</span>
        </div>
        <div class="flex">
          <span>{{$t('auth.name')}}：</span>
           <span>{{itm.name}}</span>
        </div>
        <div class="flex">
          <span>{{$t('accounts')}}：</span>
           <span>{{itm.account}}</span>
        </div>
        <div class="flex">
           <span>{{$t('legaltrade.money_code')}}：</span>
           <img class="pic" :src="itm.pic" @click="show_pic(itm.pic)">
        </div>
        
      </div> -->
      <!-- <div class="flex">
        <span>{{type == 'buy'?$t('legal.shoper'):$t('legal.buyer')}} {{$t('legal.account')}}：</span>
        <span v-if="msg.type == 'buy'">{{msg.user_cash_info.real_name || '无'}}</span>
      <router-link v-if="msg.type=='buy'" :to="{path:'/legalSeller',query:{sellerId:msg.seller_id}}" tag="span">{{msg.seller_name}}</router-link>
      </div> -->
      <!-- <div class="flex">
        <span>{{type == 'buy'?$t('legal.shoper'):$t('legal.buyer')}} {{$t('legal.phone')}}：</span>
        <span v-if="msg.user_cash_info">{{msg.user_cash_info.account_number}}</span>
        <span >{{msg.phone}}</span>
      </div>
      <div class="flex">
          <span>{{$t('legal.reference')}}：</span>
           <span>{{msg.thisid}}</span>
        </div> -->
      
      
      <div class="btns flex" v-show="msg.status==1&&type=='buy'">
        <div class="btn" @click="showCancel = true">{{$t('legal.orderceil')}}</div>
        <div class="btn blue_bg" @click="btnClick()">{{$t('legal.mypayed')}}</div> <span>(请您尽快在15分钟内确认操作)</span>
      </div>
      <!-- <div class="btns flex" v-show="msg.status==3&&msg.type=='sell'">
        <div class="btn" @click="">确认收款</div>
      </div> -->
    </div>
    <div class="cancel-box" v-if="showCancel">
      <div class="content">
        <div>{{$t('legal.ceilorder')}}</div>
        <div>{{$t('legal.notceil')}}</div>
        <!-- <div>
          <input type="checkbox" v-model="hasPay" id="haspay">
          <label for="haspay">我还没有付款给对方</label>
        </div> -->
        <div class="yes-no flex">
          <div @click="showCancel = false">{{$t('legal.ceil')}}</div>
          <div @click="cancel">{{$t('legal.confirm')}}</div>
        </div>
      </div>
    </div>
    <div class="confirm-box" v-if="showConfirm">
      <div class="content">
        <div>{{$t('legal.paysure')}}</div>
        <div>{{$t('legal.youpayed')}}</div>
        <div>{{$t('legal.freeze')}}</div>
        <div class="yes-no flex">
          <div @click="showConfirm = false">{{$t('legal.ceil')}}</div>
          <div @click="confirm">{{$t('legal.confirm')}}</div>
        </div>
      </div>
    </div>
    <!--预览图片--->
    <div class="fixed w100 flex alcenter center shadow" v-if="showPic" @click="showPic = false">
       <img class="previewImg" :src="previewImg">
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      msg: {type:'buy'},
      token: "",
      showConfirm: false,
      showCancel: false,
      hasPay: false,
      id: "",
      type: "",
      // status: -1
      previewImg:'',
      showPic:false,
      sellInfo: []
    };
  },
  created() {
    var token = window.localStorage.getItem("token") || "";
    if (token) {
      this.token = token;
      this.id = this.$route.query.id;
      this.type = this.$route.query.type;
      //console.log(this.$route.query.id, this.id);
      this.getData();
    }
  },
  methods: {
    btnClick() {
      this.showConfirm = true
    },
    // 卖家信息
    getMerchantInfo() {
      this.$http({
        url: "/api/merchant/info",
        params: {
          id: this.msg.user_cashier[0].thisid
        },
        headers: { Authorization: this.token }
      }).then(res => {
        // this.sellInfo = res.data.message
      })
    },
    getData() {
      var i = layer.load();
      this.$http({
        url: "/api/legal/order_info",
        params: {
          id: this.id
        },
        headers: { Authorization: this.token }
      }).then(res => {
        layer.close(i);
        //console.log(res);
        if (res.data.type == "ok") {
          this.msg = res.data.message;
          this.status = res.data.message.status;
          this.getMerchantInfo()
        }
      });
    },
    connect(){
       this.$router.push({path:'/chat',query:{id:this.msg.thisid}})
    },
    cancel() {
      var i = layer.load();
      this.$http({
        url: "/api/legal/cancel",
        method: "post",
        data: { id: this.id },
        headers: { Authorization: this.token }
      })
        .then(res => {
          layer.close(i);
          // //console.log(res);
          layer.msg(res.data.message);
          if (res.data.type == "ok") {
            setTimeout(() => {
              location.reload();
              // this.$router.push('/legalRecord')
            }, 1000);
          }
        })
        .then(() => {
          this.showCancel = false;
        });
    },
    confirm() {
      var i = layer.load();
      this.$http({
        url: "/api/legal/pay",
        method: "post",
        data: { id: this.id },
        headers: { Authorization: this.token }
      })
        .then(res => {
          layer.close(i)
          // //console.log(res);
          layer.msg(res.data.message);
          if (res.data.type == "ok") {
            setTimeout(() => {
              location.reload();
              // this.$router.push('/legalRecord')
            }, 1000);
          }
        })
        .then(() => {
          this.showConfirm = false;
        });
    },
    //预览图片
    show_pic(pic){
        this.previewImg = pic;
        this.showPic = true;
    }
  }
};
</script>

<style lang='scss'>
.order_detail{
  padding: 30px 60px 60px;
  background:#fff;
}
.order_detail .detail-top{
  display:flex;
  justify-content: space-between;
  align-items: flex-start;
  flex-direction: row;
  flex-wrap: nowrap;
}
 .order_detail .detail-top .detail-top-one .p-title, 
 .order_detail .detail-top .detail-top-three .p-title, 
 .order_detail .detail-top .detail-top-two .p-title {
    height: 30px;
    line-height: 30px;
    color: #999;
    font-size: 12px;
}
.order_detail .detail-top .detail-top-one div:first-child h6 {
    height: 46px;
    font-size: 28px;
    line-height: 46px;
    color: #597ab9;
}
.order_detail .detail-top .detail-top-one div:first-child h6 span{
    font-size: 16px;
}
.order_detail .detail-top .detail-top-one div h6 {
    margin-bottom: 10px;
}
.order_detail .detail-top-one{
  flex: 0.7;
}
.order_detail .detail-top-two{
  flex:0.7;
  margin-right:120px;
}
.order_detail .detail-top-three{
  flex:1;
}
.prompt{
  padding: 19px 40px 0;
  background:#fff;
}
.prompt .tips{
  padding: 0 20px;
  width: 100%;
  height: 40px;
  background-color: #f8f9fb;
  font-size: 12px;
  display:flex;
  align-items:center;
}
.prompt .tips p{
  color: #6c85ae;
}
.prompt .tips p span{
  display: inline-block;
  vertical-align: sub;
  margin-right: 9px;
  width: 16px;
  height: 16px;
  background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABbElEQVQ4jY3TwUtUYRQF8J9vbGYKi2AQg1CYocgaawKZom2KGLZr0c6VUAs3/RFui0DBYIKhbRBthBbqH1ArEYUWKW4TQaFJmVBavPdkevPe0IEPPu6553C/j3P75hc+SeAO5vAE5ai2gy9oYLuzOei457GITbzCKArRuR3VNrGMi7Gov0O8gsnkOAkEeIGb0YTteII3aeJquWR2pubqQCFJPcbr2LEauXZh4tEt9VrF9cGBNPolqv3CD8uldfzY23d41LK1e5BG5zAXYDqNrZZLxsdGFAsX0ugY0wEqacyzqfsGS1cUi/leBpUgi2l+/goOj1q9DNqBMCRduHvj2vl9ZOhylsFeIExYFy4Vw7fXaxUPx4azDFYDvMdpVse3jR0f17bTqFM0cg8mnv/EEOqd7K/fJ/I5PqxsZHkvo9kXLdP/RjnGukSU25jBEs56CM/wDk8jzT/b2MY87uEtvuMPWtiKajVhhI9j0V+6/EtabsxMFwAAAABJRU5ErkJggg==);
}
#legal-pay {
  width: 1200px;
  margin: 50px auto;
  .pic{
    width: 180px;
    height: 180px;
    cursor: pointer;
  }
  > .title {
    background: #f8f8f8;
    //margin-bottom: 20px;
    margin-bottom:2px;
    padding: 20px 0;
    // font-size: 20px;
    // line-height: 60px;
    > span {
      padding: 0 30px;
    }
    > div {
      padding: 0 30px 0;
    }
    > span:last-child {
      font-weight: 600;
    }
  }
  > .info {
    background: #f8f8f8;
    padding: 0 30px;
    line-height: 40px;
    
    span:first-child {
      width: 140px;
    }
    > .btns {
      padding: 20px 0;
     
      > div {
         cursor: pointer;
        color: #fff;
        border-radius: 2px;
        padding: 0 16px;
        background: #2e1b85;
        margin-right: 30px;
        font-size: 14px;
      }
      > div:first-child {
        background: #ccc;
        color: #333;
      }
    }
  }
  > .cancel-box,
  > .confirm-box {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7);
    > .content {
      margin: 200px auto 0;
      border-radius: 2px;
      width: 360px;
      background: #fff!important;
      line-height: 40px;
      text-align: center;
      > div:first-child {
        font-weight: 600;
      }
      > .flex {
        margin-top: 10px;
        border-top: 1px solid #ccc;
        cursor: pointer;
        div {
          width: 50%;
        }
        > div:first-child {
          border-right: 1px solid #ccc;
        }
      }
    }
  }
}
.shadow{
  height: 100%;
  top: 0;
  left: 0;
  background: rgba($color: #000000, $alpha: 0.5);
  position: fixed;
}
.shadow img{
  width: 50%;
  max-height: 80%;
}
.my-user[data-v-4dbd84e4] {
    margin-top:70px;
    margin-bottom: 20px;
    padding: 0 60px 0 20px;
    height: 100px;
    background-image: url(../../static/imgs/wode_bg.2b21aaa.png);
    background-size:100%;
    display: flex;
    flex-direction: row;
    align-items: center;
}
.my-user .myInfo{
  display: flex;
  flex-direction: row;
  align-items: center;
}
.my_img{
  margin-right:20px;
}
.my_img img{
  width:60px;
  height:60px;
}
.userName{
  font-size: 18px;
  color: #fff;
}
.userInfo{
  flex: 1;
  display: flex;
  justify-content: space-around;
  color:#fff;
}
.userInfo .item{
  text-align: center;
  font-size:24px;
}
</style>
