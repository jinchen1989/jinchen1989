<template>
	<div id="register-box" class="bg-main clr-part">
		<indexHeader></indexHeader>
		<div class="reg-content">
			<div class="register-title">{{$t('regidters')}}</div>
			<div class="tab">
				<span :class="{active:isMb}" @click="setIsMb(true)">{{$t('register.phone')}}</span>
				<span :class="{active:!isMb}" @click="setIsMb(false)">{{$t('register.email')}}</span>
			</div>
			<div class="step-one" v-show="!codeTrue">
				<div class v-if="isMb">
					<div class="tip">{{$t('register01.country')}}</div>
					<div class="flex alcenter" v-if="isMb">
						<el-select v-model="front" clearable filterable :placeholder="$t('register.placeholder.country')" style="width:400px;">
							<el-option v-for="(item,index) in countrys" :key="index" :label="`${item[`name_${$store.state.lang}`]} (${item.area_code})`" :value="item.area_code"></el-option>
						</el-select>
					</div>
					<div class="ml20 grayc ft12 select_country">{{$t('register01.selectCountry')}}</div>
				</div>
				<div class="account-box">
					<div class="tip">{{isMb?$t('register.label.phone'):$t('register.label.email')}}</div>
					<div class="flex">
						<el-input :type="isMb?'number':''" v-model="account" :placeholder="isMb?$t('register.placeholder.phone'):$t('register.placeholder.email')" style="width:400px;" />
					</div>
				</div>
				<div class="tip" style="margin-bottom:10px;">
					{{$t('register.label.code')}}
					<br />
					<span class="red">({{$t('register.notice')}})</span>
				</div>
				<div class="code-box bdr-part">
					<el-input type="text" v-model="code" :placeholder="$t('register.placeholder.code')" class="code flex1" />
					<button :disabled="!isCheck" type="button" class="code-btn redBg" :class="[isCheck?'':'pointer']" @click="sendCode">{{$t('register.sendcode')}}</button>
				</div>
				<!-- <button class="confirm-btn redBg" @click="checkCode" type="button">确认</button> -->
			</div>
			<div class="step-two">
				<div class="pwd-box pass-box1">
					<div class="tip">{{$t('register.label.password')}}</div>
					<el-input
						:type="showpass?'text':'password'"
						autocomplete="new-password"
						class="pwd-input"
						style="width: 400px;"
						maxlength="16"
						v-model="pwd"
						id="pwd"
						:placeholder="$t('register.placeholder.password')"
					/>
					<img src="../assets/images/showpass.png" alt v-if="showpass" @click="showpass = false" />
					<img src="../assets/images/hidepass.png" alt v-if="!showpass" @click="showpass = true" />
				</div>
				<div class="repwd-box pass-box1">
					<div class="tip">{{$t('register.label.confirmPass')}}</div>
					<el-input
						:type="showrepass?'text':'password'"
						autocomplete="new-password"
						class="repwd-input"
						style="width: 400px;"
						maxlength="16"
						v-model="repwd"
						:placeholder="$t('register.placeholder.confirmPass')"
					/>
					<img src="../assets/images/showpass.png" alt v-if="showrepass" @click="showrepass = false" />
					<img src="../assets/images/hidepass.png" alt v-if="!showrepass" @click="showrepass = true" />
				</div>
				<div class="invite-box">
					<div class="tip">{{$t('register.label.invitecode')}}</div>
					<el-input type="text" :placeholder="$t('register.placeholder.invitecode')" v-model="invite" class="invite-input" style="width:400px;" />
				</div>
				<p class="flex alcenter ft12 agreement">
					<input id="agree" v-model="isCheck" @click="isCheck = !isCheck" type="checkbox" />
					<label for="agree">
						{{$t('register.agree')}}
						<router-link to="/aggrement">{{$t('register.mian')}}</router-link>
					</label>
				</p>
				<button type="button" @click="register" :disabled="!isCheck" :class="[isCheck?'':'pointer']" class="btn1 ft16">{{$t('registers')}}</button>
			</div>
			<!--<div class="rg_ctbox">
            <img src="../assets/images/chatu.png" alt="">
			</div>-->
		</div>
	</div>
</template>

<script>
import countrys from '../lib/countrys.js'
import indexHeader from "@/view/indexHeader";
export default {
	components: {
		indexHeader
	},
	data() {
		return {
			showpass: false,
			showrepass: false,
			codeTrue: false, //验证码是否正确
			isMb: true,	//是否为手机注册
			front: "", // 所属国家code
			account: "", //用户名
			pwd: "", //密码
			repwd: "", //重复密码
			code: "", //验证码
			invite: "", //邀请码
			timer: null, //倒计时timer
			countrys,
			areaCode: 0,
			disable: true,
			isCheck: false,
			real_name: '',
			// card_type: '身份证',
			card_id: '',
			currentSelectValue: '',
			selectIndex: 0,
		};
	},
	// beforeRouteEnter是每次进入都会执行
	// beforeRouteEnter(to, from, next) {
	//   function browserRedirect() {
	//       var sUserAgent = navigator.userAgent.toLowerCase();
	//       if (/ipad|iphone|midp|rv:1.2.3.4|ucweb|android|windows ce|windows mobile/.test(sUserAgent)) {
	//           //跳转移动端页面
	//           window.location.href="https://www.hxex.com/register.html?code=cGnpHuLo";
	//           next();
	//       } else {
	//           //跳转pc端页面
	//           // window.location.href="http://f.jcngame.com/fanfan20171208//fanmai/index.html";
	//           next();
	//       }
	//   }
	// },
	created() {
		this.checkPt()
		this.invite = this.$route.query.code || '';
	},
	methods: {
		checkPt() {
			let sUserAgent = navigator.userAgent.toLowerCase();
			if (/ipad|iphone|midp|rv:1.2.3.4|ucweb|android|windows ce|windows mobile/.test(sUserAgent)) {
				console.log("移动端登陆")
				//跳转移动端页面
				if (window.location.href.indexOf("?") != -1) {
					var can = this.getCaption(window.location.href, 1)
					window.location.href = "http://www.libra.com/register.html" + '?' + can;
				} else {
					window.location.href = "http://www.libra.com/register.html";
				}

			} else {
				console.log("电脑登陆")
				//跳转pc端页面
				// window.location.href="http://f.jcngame.com/fanfan20171208//fanmai/index.html";
			}
		},
		getCaption(obj, state) {
			let index = obj.lastIndexOf("\?");
			if (state == 0) {
				obj = obj.substring(0, index);
			} else {
				obj = obj.substring(index + 1, obj.length);
			}
			return obj;
		},
		// 获取地区列表
		// getRegion(id, type, name) {
		//   if (type == "") {
		//     this.district = { id: id, name: name };
		//     return;
		//   } else if (type == "cities") {
		//     if (name == this.province.name) {
		//       return;
		//     }
		//   } else if (type == "districts") {
		//     if (name == this.city.name) {
		//       return;
		//     }
		//   }
		//   var pId = '';
		//   //  if(id != ''){
		//   //    data.parent_id = id;
		//   //  }
		//   if (id !== "") {
		//     pId = "?parent_id=" + id;
		//   }


		//   this.$http({
		//     url: "/api/region" + pId,
		//     method: "get"
		//   }).then(res => {
		//     ////console.log(res.data);
		//     if(res.data.type == 'ok'&&res.data.message.length != 0){

		//       if (type == "provinces") {
		//         this.provinces = res.data.message;
		//       } else if (type == "cities") {
		//         this.province = { name: name, id: id };
		//         this.city = { id: "", name: "请选择市" };
		//         this.district = { id: "", name: "请选择区" };
		//         this.cities = res.data.message;
		//       } else {
		//         this.district = { id: "", name: "请选择区" };
		//         this.city = { name: name, id: id };
		//         this.showCities = false;
		//         this.districts = res.data.message;
		//       }
		//     }
		//   });
		// },
		// 切换注册方式
		setIsMb(boo) {
			this.account = "";
			this.pwd = "";
			this.repwd = "";
			this.code = "";
			this.invite = "";
			this.isMb = boo;
			this.codeTrue = false;
			this.front = ""
			clearInterval(this.timer);
			var codeBtn = document.querySelector(".code-btn");
			this.isCheck = false;
			codeBtn.innerHTML = this.$t('code');
		},
		// 发送验证码
		sendCode(e) {
			let isMb = this.isMb;
			let url = this.isMb ? "send/phone" : "send/email";
			const reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9])+\.([A-Za-z]{2,4})$/
			if (this.account == "") {
				layer.msg(isMb ? this.$t("register.placeholder.phone") : this.$t("register.placeholder.email"))
				return;
			} else if (!isMb && !reg.test(this.account)) {
				layer.msg(this.$t('register.emailError'))
				return
			} else if (e.target.disabled) {
				return;
			}
			// else if (isMb) {
			// var reg = /^1[345678]\d{9}$/;
			// if (!reg.test(this.account)) {
			//   layer.msg("您输入的手机号不符合规则");
			//   return;
			// }
			// } else if (!isMb) {
			// var emreg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
			// if (this.account == '') {
			// 	layer.msg(this.$t('register.emailnum'));
			// 	return;
			// } else {
			// 	url = "send/email";
			// }
			// }
			localStorage.setItem("account", this.account)
			let data = { number: this.account, type: 'regist', };
			if (isMb) {
				data.front = this.front
			}
			var loa = layer.load();
			this.$http({
				url: "/api/" + url,
				method: "post",
				data
			}).then(res => {
				if (res.data.type != "error" && res.data.type != "fail") {
					var time = 60;
					this.timer = setInterval(() => {
						e.target.innerHTML = time + "s";
						e.target.disabled = true;
						if (time == 0) {
							e.target.innerHTML = this.$t('code');
							e.target.disabled = false;
							clearInterval(this.timer);
							return;
						}
						time--;
					}, 1000);
				}
				layer.close(loa);
				layer.msg(res.data.message);
			});
		},
		// 验证验证码
		checkCode() {
			if (this.account == '') {
				layer.msg(this.$t('lay.paccount')); return;
			}
			else if (this.code == "") {
				layer.msg(this.$t('lay.notcode'));
				return;
			} else {
				let data = {};
				let url = "user/check_email";
				if (this.isMb) {
					data = { mobile_code: this.code };
					url = "user/check_mobile";
				} else {
					data = { email_code: this.code };
				}
				var loa = layer.load();
				this.$http({
					url: "/api/" + url,
					method: "post",
					data: data
				}).then(res => {
					layer.close(loa);
					layer.msg(res.data.message);
					if (res.data.type == "ok") {
						this.codeTrue = true;
						// this.getRegion("", "provinces");
					}
				});
			}
		},
		// 注册
		register() {
			// 验证国家
			if (this.isMb && this.front == "") {
				layer.msg(this.$t("register.placeholder.country"))
				return;
			}
			// 验证手机号码/邮箱
			const mailReg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9])+\.([A-Za-z]{2,4})$/
			if (this.account == '') {
				layer.msg(this.isMb ? this.$t("register.placeholder.phone") : this.$t("register.placeholder.email"))
				return;
			} else if (!this.isMb && !mailReg.test(this.account)) {
				layer.msg(this.$t('register.emailError'))
				return
			}
			// 验证 验证码
			if (this.code == '') {
				layer.msg(this.$t('lay.notcode'));
				return;
			}
			let regPsws = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,16}$/;
			if (this.pwd == "") {
				layer.msg(this.$t('lay.inpwd'));
				return;
			} else if (this.pwd.length < 6 || this.pwd.length > 16) {
				layer.msg(this.$t('lay.pwdlength')); // 验证密码长度
				return;
			} else if (!regPsws.test(this.pwd)) {
				layer.msg(this.$t('lay.pwdcom')); // 验证密码格式
				return;
			} else if (this.repwd == "") {
				layer.msg(this.$t('lay.repwd'));
				return;
			} else if (this.pwd !== this.repwd) {
				layer.msg(this.$t('lay.twopwd'));
				return;
			}

			const account = localStorage.getItem("account")
			if (account != this.account) {
				layer.msg(this.$t('register.codeError'))
			}

			let data = {
				number: this.account,
				code: this.code,
				password: this.pwd,
				re_password: this.repwd,
				extension_code: this.invite,
			};
			// 手机号注册添加地区信息
			if (this.isMb) {
				let area = this.countrys.filter(f => f.area_code == this.front)[0]
				data.nationality = area.name_cn
				data.itc = area.area_code
			}
			console.log(data)
			var loa = layer.load();
			this.$http({
				url: "/api/" + "user/register",
				data: data,
				method: "post",
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
				}
			}).then(res => {
				layer.close(loa);
				layer.msg(res.data.message);
				if (res.data.type == "ok") {
					this.$router.push("/components/login");
				}
			});
		}
	}
};
</script>

<style lang='scss' scoped>
#register-box {
	padding-top: 43px;
	padding-bottom: 48px;
	background-color: #242e48;
	.reg-content {
		width: 510px;
		background: #fff;
		border-radius: 4px;
		margin: 0 auto 0;
		padding: 32px 45px;
		position: relative;
		.register-title {
			color: #263241;
			text-align: center;
			font-size: 36px;
		}
		.tip {
			margin: 10px 0;
			font-size: 12px;
		}
		.code-btn {
			cursor: pointer;
			background: #357ce1;
		}
		.pointer {
			cursor: not-allowed;
			opacity: 0.6;
		}
		.tab {
			margin: 20px 0;
			cursor: pointer;
			span {
				margin-right: 20px;
				padding-bottom: 3px;
			}
			.active {
				font-weight: bold;
				color: #357ce1;
				border-bottom: 2px solid #357ce1;
			}
		}
		.step-one {
			.code-box {
				display: flex;
				justify-content: space-between;
				width: 400px;
				height: 40px;
				background: #fff;
				/deep/ .el-input__inner {
					border-radius: 4px 0 0 4px;
				}
				button {
					border: none;
					line-height: 40px;
					width: 93px;
					color: #fff;
					border-radius: 0 4px 4px 0;
				}
			}
			.select_country {
				margin: 0;
			}
		}

		.step-two {
			.pass-box1 {
				width: 301px;
				height: 68px;
				img {
					cursor: pointer;
					width: 25px;
					right: 10px;
					position: relative;
					left: 370px;
					bottom: 35px;
				}
			}
			.agreement {
				margin: 10px 0;

				input {
					width: 16px;
					margin-right: 5px;
				}
				label {
					cursor: pointer;
					a {
						color: #332c58;
						&:hover {
							color: #357ce1;
						}
					}
				}
			}

			.btn1 {
				color: #fbfcfd;
				background: #357ce1;
				width: 400px;
				margin-bottom: 25px;
				border-radius: 4px;
			}
		}
	}
}

// .rg_ctbox {
// 	width: 310px;
// 	right: 10px;
// 	position: absolute;
// 	top: 36%;
// 	.ewm {
// 		margin-top: 10%;
// 		width: 68px;
// 		height: 68px;
// 		box-shadow: 0 0 10px #332c58;
// 	}
// 	.bd_dashed {
// 		border-bottom: 1px dashed #332c58;
// 	}
// }
</style>



