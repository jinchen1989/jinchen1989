<template>
	<div data-v-314f53c6="" class="container">
		<div class='smallTitle'>
			<div class="item_link" @click="goTo('/legalTrade')">{{$t('fbjy')}}</div>		
			<div class="item_link" @click="dialogVisible = true">{{$t('fbgg')}}</div>		
			<div class="item_link active" @click="goTo('/myAdvert')">{{$t('wdgg')}}</div>		
			<div class="item_link" @click="goTo('/merchants')">{{$t('rzsj')}}</div>		
		</div>
	    <div data-v-68c6c4ce="" data-v-f50e276a="" class="type-nav flex-box flex-direction-row flex-justify-between flex-align-item-start flex-wrap-nowrap">
		    <div data-v-68c6c4ce="" data-v-f50e276a="" class="nav flex-box flex-direction-row flex-justify-start flex-align-item-start flex-wrap-nowrap">
		      	<a data-v-f50e276a="" data-v-68c6c4ce="">广告管理</a>
		    </div>
	    </div>
	    <div data-v-70457626="" class="index-list">
	     	<table data-v-70457626="">
	      		<thead data-v-70457626="">
	       			<tr data-v-70457626="">
	        			<th data-v-70457626="" style="">{{$t('ggdh')}}</th>
	        			<th data-v-70457626="" style="width: 120px;">{{$t('gglx')}}</th>
	        			<th data-v-70457626="">{{$t('jyzl')}}</th>
	        			<th data-v-70457626="">{{$t('ywcsl')}}</th>
	        			<th data-v-70457626="">{{$t('jg')}}</th>
	        			<th data-v-70457626="">{{$t('yjl')}}</th>
	        			<th data-v-70457626="">{{$t('zt')}}</th>
	        			<th data-v-70457626="">{{$t('caozuo')}}</th>
	       			</tr>
	      		</thead>
	      		<tbody data-v-70457626=""></tbody>
	     	</table>
	     	<div data-v-70457626="" class="no-list">
	      		<img data-v-70457626="" src="../../static/imgs/noLists.png" alt="" />
	      		<h6 data-v-70457626="" style="font-size: 14px; color: rgb(201, 208, 220); font-weight: normal;">{{$t('zwsj')}}</h6>
	     	</div>
	    </div>
	    <el-dialog
		  :visible.sync="dialogVisible"
		  width="20%" center>
		  	<div class="authBox">
			  <img class="top_img" src="../../static/imgs/authentication.png" />
			  <img class="close_img" src="../../static/imgs/close.svg"  @click="dialogVisible = false"/>
			  <div class="box_tip">{{$t('qqrz')}}</div>
			  <div slot="footer" class="dialog-footer">
			    <el-button class="cencel" @click="dialogVisible = false">">{{$t('quxiao')}}</el-button>
			    <el-button class="confirm" type="primary" @click="goTo('/merchants')">{{$t('queding')}}</el-button>
			  </div>
			</div>
		</el-dialog>
   </div>
</template>

<script>
	export default{
		data() {
			return {
				dialogVisible: false
			}
		},
		created() {

		},
		methods: {
			goTo(url) {
				this.$router.push({path:url})
			}
		}
	}
</script>

	<style type="text/css" scoped>
		.el-dialog__header{
		display: none!important;
	}
	.el-dialog__body{
		padding:0!important;
	}
	.el-dialog{
		margin-top:35vh!important;
	}
	.authBox{
		position: relative;
	}
	.top_img{
		position: absolute;
		top:-42px;
		left:50%;
		margin-left:-48px;
		width: 97px;
    	height: 79px;
	}
	.box_tip{
		padding:80px 24px 20px;
		text-align: center;
	}
	.close_img{
		width:10px;
		height:10px;
		position: absolute;
		right:16px;
		top:16px;
		transition: .5s;
		-moz-transition: .5s;
		-webkit-transition: .5s;
		-o-transition: .5s
	}

	.close_img:hover {
		-webkit-transform: rotate(180deg);
		transform: rotate(180deg)
	}
	.dialog-footer{
		padding: 0 50px 20px;
		display: flex;
		justify-content: space-around;
		align-items: center;
	}
	.dialog-footer .cencel{
		display: block;
	    height: 30px;
	    padding: 0 16px;
	    border: 1px solid #597ab9;
	    border-radius: 3px;
	    font-family: PingFangSC-Regular;
	    font-size: 12px;
	    color: #597ab9;
	    line-height: 30px;
	    word-break: break-all;
	}
	.dialog-footer .confirm{
		display: block;
	    height: 30px;
	    padding: 0 16px;
	    border: 1px solid #597ab9;
	    border-radius: 3px;
	    font-family: PingFangSC-Regular;
	    font-size: 12px;
	    background: #597ab9;
    	color: #fff;
	    line-height: 30px;
	    word-break: break-all;
	}
	.container{
		margin: 0 auto;
	    padding-right: 20px;
	    width: 1200px;
	}
	.type-nav[data-v-f50e276a] {
	    padding: 0 20px;
	    height: 48px;
	    background: #fff;
	    align-items: flex-start;
	}
	.type-nav .nav a[data-v-f50e276a] {
	    position: relative;
	    margin-right: 30px;
	    font-size: 14px;
	    line-height: 48px;
	    font-weight: 500;
	    color: #333;
	}
	.index-list[data-v-70457626] {
	    padding: 20px 40px 30px;
	    margin-top: 2px;
	    background-color: #fff;
	}
	.index-list table[data-v-70457626] {
	    width: 100%;
	    border: 0;
	    margin: 0;
	    border-collapse: collapse;
	    border-spacing: 0;
	    text-align: right;
	}
	.index-list table thead tr[data-v-70457626] {
	    height: 40px;
	    background-color: #fafafb;
	    border-bottom: 1px solid #f0f1f3;
	    line-height: 40px;
	    font-size: 12px;
	    color: #888;
	}
	.index-list table tr th[data-v-70457626]:first-child {
	    padding-left: 20px;
	    text-align: left;
	}
	.index-list table tr th[data-v-70457626]:last-child {
	    padding-right: 20px;
	}
	.index-list .no-list[data-v-70457626] {
	    margin-top: 100px;
	}
	.index-list .no-list img[data-v-70457626] {
	    width: 175px;
	    height: 100px;
	    display: block;
	    margin: 0 auto;
	}
	.index-list .no-list h6[data-v-70457626] {
	    height: 34px;
	    line-height: 34px;
	    font-size: 14px;
	    color: #999;
	    text-align: center;
	}
	.smallTitle{
		padding: 0px;
		/*border-bottom:20px solid #7889a9;*/
		display:flex;
		flex-direction: row;
	}
	.smallTitle .item_link{
		margin-right:30px;
		padding: 20px 0;
		cursor: pointer;
	}
	.smallTitle .item_link.active{
		border-bottom:2px solid #0FD5FF;
	}
</style>