<template>
  <div class="indexBlackes bg-main" :class="{mobile:$store.state.isMobile}">
    <indexHeader v-if="!$store.state.isMobile"></indexHeader>
    <mobile-header v-else></mobile-header>
    <router-view class="home-route-wrap" />
    <!-- <indexFooter></indexFooter>       -->
  </div>
</template>
<script>
import indexHeader from "@/view/indexHeader";
import homeContent from "@/view/homeContent";
import indexFooter from "@/view/indexFooter";
import mobileHeader from "@/components/mobile/mobile-header.vue";
export default {
  components: { indexHeader, homeContent, indexFooter, mobileHeader },
  data() {
    return {
      msg: "",
    };
  },
  watch: {
    $route(to, from) {
      if (to.name == "homeContent") {
        $("#index-head").css("background", "#110a5d");
      } else {
        $("#index-head").css("background", "#110a5d");
      }
    },
  },
  methods: {},
  created() {
    this.msg = this.$route.query.msg;
    eventBus.$emit("alert", this.msg);
    // this.$router.push({name:'homeContent'})
    // this.$http({
    //     method:'get',
    //     url:'https://api.HQ.pro/market/tickers?AccessKeyId=c96392eb-b7c57373-f646c2ef-25a14&SignatureMethod=HmacSHA256&SignatureVersion=2&Timestamp='+new Date().toUTCString()
    //     ,headers:{
    //         'Content-Type':'application/x-www-form-urlencoded'
    //     }
    // }).then(res=>{
    //     //console.log(res)
    // })
  },
};
</script>
<style lang="scss">
#index-head {
  background: #110a5d;
}
.indexBlackes {
  min-height: 1080px;
  &.mobile {
    min-height: 100vh;
    margin-top: 0.5rem;
    .home-route-wrap {
      //   margin-top: ;
      height: calc(100vh - 1rem);
      overflow-y: auto;
    }
  }
}
</style>





