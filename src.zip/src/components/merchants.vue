<template>
	<div data-v-314f53c6="" class="container">
		<div class='smallTitle'>
			<div class="item_link" @click="goTo('/legalTrade')">{{$t('fbjy')}}</div>
			<div class="item_link" @click="dialogVisible = true">{{$t('fbgg')}}</div>
			<div class="item_link" @click="goTo('/myAdvert')">{{$t('wdgg')}}</div>
			<div class="item_link active" @click="goTo('/merchants')">{{$t('rzsj')}}</div>
		</div>
	    <div data-v-68c6c4ce="" data-v-f50e276a="" class="type-nav flex-box flex-direction-row flex-justify-between flex-align-item-start flex-wrap-nowrap">
		    <div data-v-68c6c4ce="" data-v-f50e276a="" class="nav flex-box flex-direction-row flex-justify-start flex-align-item-start flex-wrap-nowrap">
		      	<a data-v-f50e276a="" data-v-68c6c4ce="">{{$t('rzsj')}}</a>
		    </div>
	    </div>

	    <div data-v-3f8e6246="" class="info">
   			<div data-v-68c6c4ce="" data-v-3f8e6246="" class="preferential flex-box flex-direction-row flex-justify-between flex-align-item-start flex-wrap-nowrap">
    			<div data-v-3f8e6246="" data-v-68c6c4ce="">
     				<div data-v-3f8e6246="" data-v-68c6c4ce=""></div>
     				<p data-v-3f8e6246="" data-v-68c6c4ce="">{{$t('xybz')}}</p>
	    		</div>
	    		<div data-v-3f8e6246="" data-v-68c6c4ce="">
	     			<div data-v-3f8e6246="" data-v-68c6c4ce=""></div>
	     			<p data-v-3f8e6246="" data-v-68c6c4ce="">{{$t('yxzs')}}</p>
	    		</div>
	    		<div data-v-3f8e6246="" data-v-68c6c4ce="">
	     			<div data-v-3f8e6246="" data-v-68c6c4ce=""></div>
	     			<p data-v-3f8e6246="" data-v-68c6c4ce="">{{$t('flzy')}}</p>
	    		</div>
	   		</div>
	   		<p data-v-3f8e6246="" class="stepsOne"> {{$t('bzy')}} </p>
	   		<div data-v-3f8e6246="" class="place">
	    		<p data-v-3f8e6246="" class="place-p">{{$t('bze')}}<span data-v-3f8e6246="">coin@outlook.com</span></p>
	   			<div data-v-68c6c4ce="" data-v-3f8e6246="" class="place-cl flex-box flex-direction-column flex-justify-between flex-align-item-start flex-wrap-nowrap">
		     		<p data-v-3f8e6246="" data-v-68c6c4ce="">
		     			<span data-v-3f8e6246="" data-v-68c6c4ce=""></span>58COIN{{$t('zc')}} ID</p>
		     		<p data-v-3f8e6246="" data-v-68c6c4ce="">
		     			<span data-v-3f8e6246="" data-v-68c6c4ce=""></span>{{$t('grwx')}} </p>
		     		<p data-v-3f8e6246="" data-v-68c6c4ce="">
		     			<span data-v-3f8e6246="" data-v-68c6c4ce=""></span>{{$t('zczm')}}）</p>
		    	</div>
		    	<div data-v-3f8e6246="" class="place-message">
		     		<p data-v-3f8e6246="">{{$t('sfxx')}}</p>
		     		<p data-v-3f8e6246="">{{$t('yhzc')}}</p>
		     		<p data-v-3f8e6246="">{{$t('qjys')}}<span style="color: #597ab9;">libra2.0@outlook.com</span>,{{$t('yjzt')}}</p>
		    	</div>
		   	</div>
		   	<div data-v-3f8e6246="" class="stepsThree">
		    	<p data-v-3f8e6246="">{{$t('bzs')}}</p>
		    	<p data-v-3f8e6246="">{{$t('wmj')}}</p>
		   	</div>
		   	<div data-v-3f8e6246="" class="kf">
		    	<div data-v-3f8e6246="" class="img">
		     		<img data-v-3f8e6246="" src="../../static/imgs/ewm.png" alt="" />
		     		<p data-v-3f8e6246="">{{$t('rzzs')}}</p>
		    	</div>
		    	<!-- <div data-v-68c6c4ce="" data-v-3f8e6246="" class="check flex-box flex-direction-row flex-justify-center flex-align-item-center flex-wrap-nowrap">
		     		<a data-v-3f8e6246="" data-v-68c6c4ce="" class="checkbox"></a> 我已阅读并同意&nbsp;
		     		<a data-v-3f8e6246="" data-v-68c6c4ce="" href="https://58coin-support.zendesk.com/hc/zh-cn/articles/900000406846" target="_blank" style="color: rgb(89, 122, 185);">《 OTC商家积分管理制度 》。</a>
		    	</div> -->
		   	</div>
		   	<!-- <a data-v-3f8e6246="" class="btn2 three">提交申请</a> -->
		</div>
		<el-dialog
		  :visible.sync="dialogVisible"
		  width="20%" center>
		  	<div class="authBox">
			  <img class="top_img" src="../../static/imgs/authentication.png" />
			  <img class="close_img" src="../../static/imgs/close.svg"  @click="dialogVisible = false"/>
			  <div class="box_tip">{{$t('qqrz')}}</div>
			  <div slot="footer" class="dialog-footer">
			    <el-button class="cencel" @click="dialogVisible = false">{{$t('quxiao')}}</el-button>
			    <el-button class="confirm" type="primary" @click="dialogVisible = false">{{$t('queding')}}</el-button>
			  </div>
			</div>
		</el-dialog>
   </div>
</template>

<script>
	export default{
		data() {
			return {
				dialogVisible: false
			}
		},
		created() {

		},
		methods: {
			goTo(url) {
				this.$router.push({path:url})
			}
		}
	}
</script>

	<style type="text/css" scoped>
		.el-dialog__header{
		display: none!important;
	}
	.el-dialog__body{
		padding:0!important;
	}
	.el-dialog{
		margin-top:35vh!important;
	}
	.authBox{
		position: relative;
	}
	.top_img{
		position: absolute;
		top:-42px;
		left:50%;
		margin-left:-48px;
		width: 97px;
    	height: 79px;
	}
	.box_tip{
		padding:80px 24px 20px;
		text-align: center;
	}
	.close_img{
		width:10px;
		height:10px;
		position: absolute;
		right:16px;
		top:16px;
		transition: .5s;
		-moz-transition: .5s;
		-webkit-transition: .5s;
		-o-transition: .5s
	}

	.close_img:hover {
		-webkit-transform: rotate(180deg);
		transform: rotate(180deg)
	}
	.dialog-footer{
		padding: 0 50px 20px;
		display: flex;
		justify-content: space-around;
		align-items: center;
	}
	.dialog-footer .cencel{
		display: block;
	    height: 30px;
	    padding: 0 16px;
	    border: 1px solid #597ab9;
	    border-radius: 3px;
	    font-family: PingFangSC-Regular;
	    font-size: 12px;
	    color: #597ab9;
	    line-height: 30px;
	    word-break: break-all;
	}
	.dialog-footer .confirm{
		display: block;
	    height: 30px;
	    padding: 0 16px;
	    border: 1px solid #597ab9;
	    border-radius: 3px;
	    font-family: PingFangSC-Regular;
	    font-size: 12px;
	    background: #597ab9;
    	color: #fff;
	    line-height: 30px;
	    word-break: break-all;
	}
	.container{
		margin: 0 auto;
	    padding-right: 20px;
	    width: 1200px;
	}
	.type-nav[data-v-f50e276a] {
	    padding: 0 20px;
	    height: 48px;
	    background: #fff;
	    align-items: flex-start;
	}
	.type-nav .nav a[data-v-f50e276a] {
	    position: relative;
	    margin-right: 30px;
	    font-size: 14px;
	    line-height: 48px;
	    font-weight: 500;
	    color: #333;
	}
	.smallTitle{
		padding: 0px;
		//border-bottom:20px solid #7889a9;
		display:flex;
		flex-direction: row;
	}
	.smallTitle .item_link{
		margin-right:30px;
		padding: 20px 0;
		cursor: pointer;
	}
	.smallTitle .item_link.active{
		border-bottom:2px solid #0FD5FF;
	}
	.info[data-v-3f8e6246] {
	    padding: 66px 230px 95px;
	    background-color: #fff;
	    margin-top:2px;
	}
	.preferential{
		display: flex;
		justify-content: space-between;
	}
	.info .preferential>div:first-child div[data-v-3f8e6246] {
	    background-image: url(../../static/imgs/auth1.png);
	}
	.info .preferential>div:nth-child(2) div[data-v-3f8e6246] {
	    background-image: url(../../static/imgs/auth2.png);
	}
	.info .preferential>div:last-child div[data-v-3f8e6246] {
	    background-image: url(../../static/imgs/auth3.png);
	}
	.info .preferential>div div[data-v-3f8e6246] {
	    width: 92px;
	    height: 92px;
	    background-repeat: no-repeat;
	    background-position: 50%;
	    -webkit-box-shadow: 0 4px 8px rgba(89,122,185,.1);
	    box-shadow: 0 4px 8px rgba(89,122,185,.1);
	    border-radius: 46px;
   }
   .info .preferential>div p[data-v-3f8e6246] {
	    height: 56px;
	    line-height: 56px;
	    font-size: 16px;
	    color: #1e2266;
	    text-align: center;
	}
	.stepsOne[data-v-3f8e6246] {
	    height: 54px;
	    line-height: 54px;
	}
	.info .place .place-p[data-v-3f8e6246] {
	    height: 34px;
	    line-height: 34px;
	    font-size: 14px;
	    color: #333;
	}
	.info .place .place-cl[data-v-3f8e6246] {
	    padding: 10px;
	}
	.info .place .place-cl p[data-v-3f8e6246] {
	    height: 34px;
	    line-height: 34px;
	    font-size: 14px;
	    color: #999;
	}
	.info .place .place-cl p span[data-v-3f8e6246] {
	    display: inline-block;
	    margin-right: 8px;
	    width: 14px;
	    height: 14px;
	    background-image: url(../../static/imgs/yes.png);
	    vertical-align: middle;
	}
	.info .place .place-message[data-v-3f8e6246] {
	    margin-top: 5px;
	}
	.place-message[data-v-3f8e6246], .stepsOne[data-v-3f8e6246], .stepsThree[data-v-3f8e6246] {
	    font-size: 14px;
	    color: #333;
	}
	.info .place .place-message p[data-v-3f8e6246] {
	    line-height: 26px;
	}
	.stepsThree[data-v-3f8e6246] {
	    margin-top: 20px;
	}
	.stepsThree P[data-v-3f8e6246] {
	    height: 26px;
	    line-height: 26px;
	}
	.kf .img[data-v-3f8e6246] {
	    margin-top: 35px;
	}
	.kf .img img[data-v-3f8e6246] {
		display: block;
	    margin: 0 auto;
	}
	.kf .img p[data-v-3f8e6246] {
	    height: 42px;
	    line-height: 42px;
	    font-size: 12px;
	    text-align: center;
	}
</style>
