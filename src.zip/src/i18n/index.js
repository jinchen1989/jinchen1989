import Vue from 'vue'
import VueI18n from 'vue-i18n'
import store from "@/store"
Vue.use(VueI18n)

// import zh from './zh-CN'
// import en from './en'
// import han from './han'
// import jp from './jp'
// import fr from './fr'

const zh = require("./locales/zh-CN.json")
const en = require("./locales/en.json")
const kr = require("./locales/ko.json")
const jp = require("./locales/ja.json")
const fr = require("./locales/fr.json")

// let locale = store.state.lang;

// window.localStorage.setItem('locale', locale);

export default new VueI18n({
	locale: store.state.lang || "en",
	messages: { zh, en, kr, jp, fr }
})
