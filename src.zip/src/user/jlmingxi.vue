<template>
    <div style="padding:15px" class="kthy-content">
        <div style="width:800px;min-height: 1080px;margin:150px auto 0;position: relative;">
            <div style="padding:  10px;text-align: center;display: flex;justify-content: space-between;align-items: center;">
                <el-button type="primary" @click="goBack">Back</el-button>
                <!-- <span>奖励明细</span> -->
            </div>
            <div style="width:800px;margin:20px auto 0;position: relative;padding:30px;background-color:#12314A">
                <table style="width:100%;border:none;" cellpadding="0" cellspacing="0" class="myteam-table">
                    <tbody>
                        <tr v-for = "(item,index) in awardDetail" :key="index">
                            <td>+{{item.dividendNumber}} <span style="color:#b5b0b0">({{item.currencyId}})</span></td>
                            <td>{{item.createTime | formatDate}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
          
        </div>
    </div>
</template>

<script>
export default {
    name:'myteam',
    data(){
        return{
            token:'',
            userId:'',
            awardDetail:[]  //直推用户集合 
        }
    },
    filters:{
        formatDate(nS) { 
            let date = new Date(nS);
            let y = date.getFullYear();
            let MM = date.getMonth() + 1;
            MM = MM < 10 ? ('0' + MM) : MM;
            let d = date.getDate();
            d = d < 10 ? ('0' + d) : d;
            let h = date.getHours();
            h = h < 10 ? ('0' + h) : h;
            let m = date.getMinutes();
            m = m < 10 ? ('0' + m) : m;
            let s = date.getSeconds();
            s = s < 10 ? ('0' + s) : s;
            return y + '-' + MM + '-' + d + ' ' + h + ':' + m + ':' + s;
        } 
    },
    created(){
        this.selectMx()
    },
    methods:{
        goBack(){
            this.$router.go(-1)
        },
        // 开通会员
        selectMx(){
            let that = this
            this.token=localStorage.getItem('token')||'';
            this.userId=localStorage.getItem('userId')||'';

            this.$http({
                url:'/api/userpartnerlevel/findUserTeam',
                method:'post',
                data:{
                    userId:this.userId
                },
                headers:{Authorization:this.token}
            }).then(res=>{
                if(res.data.type == 'ok'){
                    console.log('res.data',res.data) 
                    that.awardDetail = res.data.message.awardDetail
                }else{
                    this.$layer.msg(res.data.message)
                }
            })
        }
    }
}
</script>

<style scoped>
    .kthy-content {
       height: 1080px;
       background-color: #000;
       color: #fff;

    }
    .kthy-header{
        display: flex;
        justify-content: space-between;
        align-items: center;
        width: 100%;
        margin: 0 auto;
        padding: 20px 10px;
        background-color: #09273F;
    }

    .myteam-table th{
       padding: 5px;
       text-align: center;
       color:#5D6E84
    }

    .myteam-table tbody td{
       padding: 5px;
       text-align: center
    }
    
</style>