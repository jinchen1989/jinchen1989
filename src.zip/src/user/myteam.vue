<template>
    <div style="padding:15px" class="kthy-content">
        <div style="width:800px;min-height: 1080px;margin:150px auto 0;position: relative;">
            <div style="color:#fff;padding:10px 0;text-align: right;cursor: pointer;" >
                
                <el-button type="primary" @click="goMinxi">奖励明细</el-button>
            </div>
            <div class="kthy-header">
                <div style="border-right:1px solid #fff;width:33%">
                    <p style="text-align:center;padding:5px 0">我的分享</p>
                    <p style="text-align:center;padding:5px 0">{{pushNumber}}</p>
                </div>
                <div style="border-right:1px solid #fff;width:33%">
                    <p style="text-align:center;padding:5px 0">团队合伙人人数</p>
                    <p style="text-align:center;padding:5px 0">{{partnerNumber}}</p>
                </div>
                <div style="width:33%">
                    <p style="text-align:center;padding:5px 0">累计奖励</p>
                    <p style="text-align:center;padding:5px 0">{{sumMoney}}</p>
                </div>
            </div>

            <div style="width:800px;margin:20px auto 0;position: relative;">
                <table style="width:100%;border:none" cellpadding="0" cellspacing="0" class="myteam-table">
                    <thead>
                        <tr>
                            <th>手机号</th>
                            <th>注册时间</th>
                            <th>合伙人等级</th>
                            <th>认证</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for = "(item,index) in pushList" :key="index">
                            <td>{{item.phone}}</td>
                            <td>{{item.createTime}}</td>
                            <td>{{item.partnerLevel}}</td>
                            <td>{{(item.isAuth === 0)?'未认证':'已认证'}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
          
        </div>
    </div>
</template>

<script>
export default {
    name:'myteam',
    data(){
        return{
            token:'',
            userId:'',
            pushNumber:'',   //我的分享
            partnerNumber:'',   //团队合伙人数量
            sumMoney:'',   //累计奖励
            pushList:[]  //直推用户集合 
        }
    },
    created(){
        this.goKthy()
    },
    methods:{
        goMinxi(){
           this.$router.push('/jlmingxi')
        },
        // 开通会员
        goKthy(){
            let that = this
            this.token=localStorage.getItem('token')||'';
            this.userId=localStorage.getItem('userId')||'';

            this.$http({
                url:'/api/userpartnerlevel/findUserTeam',
                method:'post',
                data:{
                    userId:this.userId
                },
                headers:{Authorization:this.token}
            }).then(res=>{
                if(res.data.type == 'ok'){
                    console.log('res.data',res.data) 
                    that.pushNumber = res.data.message.pushNumber
                    that.partnerNumber = res.data.message.partnerNumber
                    that.sumMoney = res.data.message.sumMoney
                    that.pushList = res.data.message.pushList
                }else{
                    this.$layer.msg(res.data.message)
                }
            })
        }
    }
}
</script>

<style scoped>
    .kthy-content {
       height: 1080px;
       background-color: #000;
       color: #fff;

    }
    .kthy-header{
        display: flex;
        justify-content: space-between;
        align-items: center;
        width: 100%;
        margin: 0 auto;
        padding: 20px 10px;
        background-color: #09273F;
    }

    .myteam-table th{
       padding: 5px;
       text-align: center;
       color:#5D6E84
    }

    .myteam-table tbody td{
       padding: 5px;
       text-align: center
    }
    
</style>