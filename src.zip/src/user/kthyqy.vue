<template>
    <div style="padding:15px" class="kthy-content2">
        <div style="width:800px;min-height: 1080px;margin:150px auto 0;position: relative;">
          
        </div>
    </div>
</template>

<script>
export default {
    name:'kthy',
    data(){
        return{
            token:'',
            userId:'',
            current:'0',
            memberList:[]
        }
    },
    created(){
        this.selectUserList()
    },
    methods:{
        // 查询会员制度列表
        selectUserList(){
            let that = this
            this.token=localStorage.getItem('token')||'';
            this.userId=localStorage.getItem('userId')||'';

            this.$http({
                url:'/api/member/list',
                method:'post',
                data:{
                },
                headers:{Authorization:this.token}
            }).then(res=>{
                if(res.data.type == 'ok'){
                    // this.$layer.msg(res.data.message)
                    that.memberList = res.data.message.slice(2,5)
                }
                // else{
                //     this.$layer.msg(res.data.message)
                // }
            })
        },
        // 开通会员
        goKthy(){
            let that = this
            let vipId
            this.token=localStorage.getItem('token')||'';
            this.userId=localStorage.getItem('userId')||'';
 
            if(this.current == '0'){
              vipId = that.memberList[0].id
            }else if(this.current == '1'){
               vipId = that.memberList[1].id 
            }else if(this.current == '2'){
               vipId = that.memberList[2].id  
            }

            this.$http({
                url:'/api/member/buyMember',
                method:'post',
                data:{
                    userId:this.userId,
                    vipId:vipId
                },
                headers:{Authorization:this.token}
            }).then(res=>{
                if(res.data.type == 'ok'){
                    this.$layer.msg(res.data.message)
                }else{
                    this.$layer.msg(res.data.message)
                }
            })
        },
        changeCurrent(e){
            let value = e.target.dataset.current
            this.current = value
        }
    }
}
</script>

<style scoped>
    .kthy-content2 {
       background-image: url('../assets/images/bg_kthyqy.png');
       background-repeat: no-repeat;
       height: 1080px;

    }
    .theli{
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
    }

    .kthy-button{
        border-radius: 10px;
        padding: 10px;
        color: #fff;
        width:200px;
    }

    .theGroupButtons{
        width:100%;
        justify-content: center;
        align-items: center;
        display: flex; 
        position: absolute;
        bottom: 300px;
        

    }

    .theBack{
       background-repeat: no-repeat;
       background-size: 100% 100%;
    }
       
    
</style>