<template>
    <div style="padding:15px" class="kthy-content">
        <div style="width:800px;min-height: 1080px;margin:150px auto 0;position: relative;">
           <!-- 切换会员等级 -->
           <div style="display:flex;justify-content: center;align-items: center;color:#fff;position: absolute;bottom: 416px;width: 100%;">
               <div style="width:164px;height:214px;" class="theBack"
                :style="{backgroundImage:(current == '0' ?'url('+'./static/imgs/one_select.png'+')':'url('+'./static/imgs/one.png'+')')}"  
                data-current='0' @click="changeCurrent($event)">
                   
               </div>
               <div style="width:164px;height:214px;margin:0 69px;"  class="theBack"
                :style="{backgroundImage:(current == '1' ?'url('+'./static/imgs/two_select.png'+')':'url('+'./static/imgs/two.png'+')')}"  
                data-current='1' @click="changeCurrent($event)">
                   
               </div>
               <div style="width:164px;height:214px;"  class="theBack"
                :style="{backgroundImage:(current == '2' ?'url('+'./static/imgs/three_select.png'+')':'url('+'./static/imgs/three.png'+')')}"  
                data-current='2' @click="changeCurrent($event)">
                   
               </div>  
           </div>
           <div class="theGroupButtons">
               <button class="kthy-button" style="background-color: #E20123" :disabled="disabled" @click="goKthy">开通会员</button>
               <button class="kthy-button" style="background-color: #938F86;margin-left:40px">暂不开通</button>
           </div>
          
        </div>
    </div>
</template>

<script>
export default {
    name:'kthy',
    data(){
        return{
            token:'',
            userId:'',
            current:'0',
            memberList:[],
            disabled:false
        }
    },
    created(){
        this.selectUserList()
    },
    methods:{
        // 查询会员制度列表
        selectUserList(){
            let that = this
            this.token=localStorage.getItem('token')||'';
            this.userId=localStorage.getItem('userId')||'';

            this.$http({
                url:'/api/member/list',
                method:'post',
                data:{
                },
                headers:{Authorization:this.token}
            }).then(res=>{
                if(res.data.type == 'ok'){
                    // this.$layer.msg(res.data.message)
                    that.memberList = res.data.message.slice(2,5)
                }
                // else{
                //     this.$layer.msg(res.data.message)
                // }
            })
        },
        // 开通会员
        goKthy(){
            this.disabled=true
            setTimeout(() => {
                this.disabled=false
            }, 3000)

            let that = this
            let vipId
            this.token=localStorage.getItem('token')||'';
            this.userId=localStorage.getItem('userId')||'';
 
            if(this.current == '0'){
              vipId = that.memberList[0].id
            }else if(this.current == '1'){
               vipId = that.memberList[1].id 
            }else if(this.current == '2'){
               vipId = that.memberList[2].id  
            }

            this.$http({
                url:'/api/member/buyMember',
                method:'post',
                data:{
                    userId:this.userId,
                    vipId:vipId
                },
                headers:{Authorization:this.token}
            }).then(res=>{
                if(res.data.type == 'ok'){
                    this.$layer.msg(res.data.message)
                }else{
                    this.$layer.msg(res.data.message)
                }
            })
        },
        changeCurrent(e){
            let value = e.target.dataset.current
            this.current = value
        }
    }
}
</script>

<style scoped>
    .kthy-content {
       background-image: url('../assets/images/bg_kthy.png');
       background-repeat: no-repeat;
       height: 1080px;

    }
    .theli{
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
    }

    .kthy-button{
        border-radius: 10px;
        padding: 10px;
        color: #fff;
        width:200px;
    }

    .theGroupButtons{
        width:100%;
        justify-content: center;
        align-items: center;
        display: flex; 
        position: absolute;
        bottom: 300px;
        

    }

    .theBack{
       background-repeat: no-repeat;
       background-size: 100% 100%;
    }
       
    
</style>