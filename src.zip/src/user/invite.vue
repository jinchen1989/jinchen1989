<template>
    <div class="mt45 bg-main">
        <img src="../assets/images/bgInvite.png" alt="" class="w100 H500">
        <div class="w90 invite_container mauto zdx99 plr40 " style="margin-bottom: 30px;">
            <!-- 我的专属推广链接 -->
            <div class="plr40 ptb20 radius10 mb10" style="background:#e0f2ff;">
                <p class="ft22 cor3">{{$t('invite.link')}}</p>
                <div class="mt20 flex alcenter cor2">
                    <div class=" radius4 flex alcenter flex1 mr30 radius5 hidden">
                        <div class=" flex1 ptb10 tc bgWhite">http://www.libra20.ai/#/components/register?code={{invite_code}}</div>
                        <div class="tc  ft16 w25 ptb10 curPer copy_link white" style="background:#79c6fa;" @click="copy_link">{{$t('invite.share')}}</div>
                    </div>
                    <div class="w30 radius4 flex alcenter radius5 hidden">
                        <div class=" flex1 tc ptb10 bgWhite">{{$t('header.code')}}：{{invite_code}}</div>
                        <div class="tc  ft16 w20 ptb10 curPer white" style="background:#79c6fa;" @click="copy" id="copy">{{$t('account.copy')}}</div>
                    </div>
                </div>
            </div>
            <!--邀请人数、持仓数量--->
            <!-- <div class="flex mb10 between mt20 ft14">
                <div class="plr10 ptb10 bgWhite w30">
                    <p class="mb10">一级邀请总人数：{{msg.first||'--'}}</p>
                </div>
                <div class="plr10 ptb10 bgWhite w30">
                    <p class="mb10">二级邀请总人数：{{msg.second||'--'}}</p>
                </div>
                <div class="plr10 ptb10 bgWhite w30">
                    <p class="mb10">三级邀请总人数：{{msg.third || '--'}}</p>
                </div>
            </div> -->

            <div class="bg-part plr20 pt20 pb50 mt20 radius8" style="display:none;">
                <div class="">
                    <p class="ft22 cor3"><span :class="{'black':tab == 1,'bold':tab == 1}" class="curPer" @click="tab = 1">返佣记录</span><span class="ml20 curPer" :class="{'black':tab == 2,'bold':tab == 2}" @click="tab = 2">持仓统计</span></p>
                    <div class="flex alcenter ft14 mt10">
                        <span>层级：</span>
                        <el-select size="mini" v-model="lever" @change="changeLever">
                            <el-option :value="item.value" :label="item.name" v-for="(item,i) in leverList" :key="i"></el-option>
                        </el-select>
                        <span class="mr10" style="margin-left:50px;">用户账号：</span>
                        <el-input placeholder="用户手机号或邮箱" style="width:350px;" size="mini" @keyup.native="inp" v-model="account" class="input-with-select"><el-button slot="append" icon="el-icon-search"></el-button> </el-input>
                    </div>
                    <div class="mt20 ft14" v-if="tab == 1">
                        <div class="flex alcenter cor2 ft14 bdb_eb pb10">
                             <span class="flex1">UID</span>
                             <span class="flex1 tc">手机号</span>
                             <span class="flex1 tc">层级</span>
                             <span class="flex1 tr pr30">SGR返佣</span>
                        </div>
                        <div class="cor3 ft14 mt20 H500 overyscroll">
                            <div class="flex alcenter mb20" v-for="(item,i) in inviteList" :key="i">
                                <span class="flex1">{{item.thisid}}</span>
                                <span class="flex1 tc">{{item.account}}</span>
                                <span class="flex1 tc">{{item.lever}}</span>
                                <span class="flex1 tr pr30">{{item.sgr_balance}}</span>
                            </div>
                            <div class="mt20 tc cor2" v-show='!inviteList.length'>{{$t('invite.nomore')}}</div>
                        </div>
                    </div>
                    <div class="mt20 ft14" v-if="tab == 2">
                        <div class="flex alcenter cor2 ft14 bdb_eb pb10">
                             <span class="flex1">UID</span>
                             <span class="flex1 tc">手机号</span>
                             <span class="flex1 tc">层级</span>
                             <span class="flex1 tc">HXB持仓</span>
                             <span class="flex1 tr pr30">SGR持仓</span>
                        </div>
                        <div class="cor3 ft14 mt20 H500 overyscroll">
                            <div class="flex alcenter mb20" v-for="(item,i) in inviteList02" :key="i">
                                <span class="flex1">{{item.thisid}}</span>
                                <span class="flex1 tc">{{item.account}}</span>
                                <span class="flex1 tc">{{item.lever}}</span>
                                <span class="flex1 tc">{{item.hxb_balance}}</span>
                                <span class="flex1 tr pr30">{{item.sgr_balance}}</span>
                            </div>
                            <div class="mt20 tc cor2" v-show='!inviteList.length'>{{$t('invite.nomore')}}</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 我的团队 -->
            <div style="padding:15px" class="kthy-content" v-if="showMyteam">
                <div style="width:100%;margin:7px auto 0;position: relative;">
                    <p style="text-align:center;color:#000;font-size:22px">我的团队</p>
                    <div style="color:#fff;padding:0px 0 10px;text-align: right;cursor: pointer;" >

                        <el-button type="primary" @click="goMinxi">奖励明细</el-button>
                    </div>
                    <div class="kthy-header">
                        <div style="border-right:1px solid #fff;width:33%">
                            <p style="text-align:center;padding:5px 0">我的分享</p>
                            <p style="text-align:center;padding:5px 0">{{pushNumber}}</p>
                        </div>
                        <div style="border-right:1px solid #fff;width:33%">
                            <p style="text-align:center;padding:5px 0">团队合伙人人数</p>
                            <p style="text-align:center;padding:5px 0">{{partnerNumber}}</p>
                        </div>
                        <div style="width:33%">
                            <p style="text-align:center;padding:5px 0">累计奖励</p>
                            <p style="text-align:center;padding:5px 0">{{sumMoney}}</p>
                        </div>
                    </div>

                    <!-- 我的团队列表 -->
                    <div style="width:100%;margin:20px auto 0;position: relative;color: #000;">
                        <table style="width:100%;border:none" cellpadding="0" cellspacing="0" class="myteam-table">
                            <thead>
                                <tr>
                                    <th>手机号</th>
                                    <th>注册时间</th>
                                    <th>合伙人等级</th>
                                    <th>是否会员</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for = "(item,index) in pushList" :key="index">
                                    <td>{{item.phone}}</td>
                                    <td>{{item.createTime | formatDate}}</td>
                                    <td>{{item.partnerLevel}}</td>
                                    <td>{{(item.isLevel === 0)?'否':'是'}}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
             <!-- 我的团队 -->

            <!-- 奖励明细 -->
             <div style="padding:15px" class="kthy-content"  v-else>
                    <div style="width:100%;margin:7px auto 0;position: relative;">
                        <p style="text-align:center;color:#000;font-size:22px">奖励明细</p>
                        <div style="text-align: center;display: flex;justify-content: space-between;align-items: center;">
                            <el-button type="primary" @click="goBack">Back</el-button>
                            <!-- <span>奖励明细</span> -->
                        </div>
                        <div style="width:100%;margin:20px auto 0;position: relative;padding:30px;background-color:#12314A;">
                            <table style="width:100%;border:none;" cellpadding="0" cellspacing="0" class="myteam-table">
                                <tbody>
                                    <tr v-for = "(item,index) in awardDetail" :key="index">
                                        <td>+{{item.dividendNumber}} <span style="color:#b5b0b0">({{item.currencyId}})</span></td>
                                        <td>{{item.createTime | formatDate}}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>




        </div>
    </div>
</template>
<script>
import "@/lib/clipboard.min.js";
export default {
    data(){
        return{
            token:'',
            rankList:[],
            inviteList:[],
            inviteList02:[],
            page:0,
            hasMore:false,
            limit:10,
            invite_code:'',
            c_name:'',
            c_rate:'',
            tab:1,
            msg:'',
            leverList:[
                {name:1,value:1},
                {name:2,value:2},
                {name:3,value:3}
            ],
            lever:'',
            account:'',
            count_inv:'', //总邀请返佣手续费
            count_release:'', //总邀请sgr返佣
            //我的团队
            userId:'',
            pushNumber:'',   //我的分享
            partnerNumber:'',   //团队合伙人数量
            sumMoney:'',   //累计奖励
            pushList:[],  //直推用户集合
            awardDetail:[],  //直推用户集合
            showMyteam:true  //显示我的团队
            //我的团队结束
        }
    },
    filters:{
        formatDate(nS) {
            let date = new Date(nS);
            let y = date.getFullYear();
            let MM = date.getMonth() + 1;
            MM = MM < 10 ? ('0' + MM) : MM;
            let d = date.getDate();
            d = d < 10 ? ('0' + d) : d;
            let h = date.getHours();
            h = h < 10 ? ('0' + h) : h;
            let m = date.getMinutes();
            m = m < 10 ? ('0' + m) : m;
            let s = date.getSeconds();
            s = s < 10 ? ('0' + s) : s;
            return y + '-' + MM + '-' + d + ' ' + h + ':' + m + ':' + s;
        }
    },
    created(){
        this.token=localStorage.getItem('token')||'';
        this.init();
        this.userInfo();
        this.getRate();
        this.getInviteAccount();
        this.inviteLog();
        this.inviteUser();
        this.getCount();
        this.selectmyTeam();  //我的团队
    },
    methods:{
        // 去往奖励明细
        goMinxi(){
           this.showMyteam = false
        },
        //返货我的团队
        goBack(){
           this.showMyteam = true
        },
        // 我的团队查看
        selectmyTeam(){
            let that = this
            this.token=localStorage.getItem('token')||'';
            this.userId=localStorage.getItem('userId')||'';
            this.$http({
                url:'/api/userpartnerlevel/findUserTeam',
                method:'post',
                data:{
                    userId:this.userId
                },
                headers:{Authorization:this.token}
            }).then(res=>{
                if(res.data.type == 'ok'){
                    that.pushNumber = res.data.message.pushNumber
                    that.partnerNumber = res.data.message.partnerNumber
                    that.sumMoney = res.data.message.sumMoney
                    that.pushList = res.data.message.pushList
                    that.awardDetail = res.data.message.awardDetail
                }else{
                    this.$layer.msg(res.data.message)
                }
            })
        },
        //总返佣

        getCount(){
            this.$http({
                url:'/api/user/invite_user_count',
                method:'get',
                headers:{Authorization:this.token}
            }).then(res=>{
                if(res.data.type == 'ok'){
                    this.count_inv = res.data.message.count_inv;
                    this.count_release = res.data.message.count_release;
                }
            })
        },
        getInviteAccount(){
            this.$http({
                url:'/api/user/invite_count',
                method:'get',
                headers:{Authorization:this.token}
            }).then(res=>{
                if(res.data.type == 'ok'){
                    this.msg = res.data.message;
                }
            })
        },
        getRate(){
            this.$http({
                url:'/api/wallet/get_info',
                method:'post',
                headers:{Authorization:this.token}
            }).then(res=>{
                if(res.data.type == 'ok'){
                    this.c_name = res.data.message.c_name;
                    this.c_rate = res.data.message.c_rate;
                }
            })
        },
        init(){
            this.$http({
                url:'/api/user/invite',
                method:'get',
                data:{},
                headers:{Authorization:this.token}
            }).then(res=>{
                var data=res.data;
                if(data.type=='ok'){
                    if(data.message.length>0){
                       this.rankList=data.message;
                    }

                }
            })
        },
        //返佣记录
        inviteLog(){
            var i = layer.load();
              this.$http({
                url:'/api/user/invite_log',
                method:'get',
                params:{level:this.lever||'',account:this.account||''},
                headers:{Authorization:this.token}
            }).then(res=>{
                layer.close(i)
                var data=res.data;
                if(data.type=='ok'){
                    this.inviteList=data.message;
                }
            });
        },
        //持仓统计
        inviteUser(){
            var i = layer.load();
             this.$http({
                url:'/api/user/invite_user',
                method:'get',
                params:{level:this.lever||'',account:this.account||''},
                headers:{Authorization:this.token}
            }).then(res=>{
                layer.close(i);
                var data=res.data;
                if(data.type=='ok'){
                    this.inviteList02=data.message;
                }
            })
        },
        //等级筛选
        changeLever(){
            if(this.tab == 1){
                this.inviteList = [];
                this.inviteLog()
            }else{
                this.inviteList02 = [];
                this.inviteUser();
            }
        },
        //手机号筛选
        inp(){
            if(this.tab == 1){
                this.inviteList = [];
                this.inviteLog()
            }else{
                this.inviteList02 = [];
                this.inviteUser();
            }
        },
        userInfo(){
           this.$http({
            url: "/api/" + "user/info",
            method: "get",
            data: {},
            headers: { Authorization: localStorage.getItem("token") }
        }).then(res => {
            if (res.data.type == "ok") {
               this.invite_code = res.data.message.invite_code
            }
            })
        },
        //复制
        copy() {
            var that = this;
            var clipboard = new Clipboard("#copy", {
                text: function() {
                return (
                    that.invite_code
                );
                }
            });
            clipboard.on("success", function(e) {
                that.flags = true;
                layer.msg(that.$t('lay.copys'));
            });
            clipboard.on("error", function(e) {
                that.flags = false;
                layer.msg(that.$t('lay.recopy'));
            });
            },

        copy_link(){
            var that = this;
            var clipboard = new Clipboard(".copy_link", {
                text: function() {
                return (
                    'http://www.libra20.ai/#/components/register?code='+that.invite_code
                );
                }
            });
            clipboard.on("success", function(e) {
                that.flags = true;
                layer.msg(that.$t('lay.copys'));
            });
            clipboard.on("error", function(e) {
                that.flags = false;
                layer.msg(that.$t('lay.recopy'));
            });
            },


    }
}
</script>
<style lang='scss'>
.H500{
    height: 500px;
}
.H34{
    height: 34px;
}
.invite_container{
    max-width: 1200px;
    margin-top: 30px;
    position: relative;
    .invite_header{
        height: 268px;
        .head{
            height: 64px;
        }
    }
}
.shadows{
    box-shadow: 0 0 8px #eee;
}

.kthy-content {
    background-color: #fff;
    color: #fff;

}
.kthy-header{
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
    margin: 0 auto;
    padding: 20px 10px;
    background-color: #09273F;
}

.myteam-table th{
    padding: 5px;
    text-align: center;
    color:#5D6E84
}

.myteam-table tbody td{
    padding: 5px;
    text-align: center
}

</style>

