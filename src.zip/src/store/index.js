import Vue from 'vue'
import Vuex from 'vuex'
import createPersistedState from "vuex-persistedstate"

Vue.use(Vuex)

export default new Vuex.Store({
	state: {
		lang: "en",
		accountNum: '',
		datas: {},
		symbol: 'BTC/2',
		currency_id: "2",
		renew: '0',
		pair: '',
		id: '1',
		priceScale: 100000000,
		isMobile: false
	},
	mutations: {
		setAccountNum(state) {
			let accountNum = window.localStorage.getItem('accountNum')
			state.accountNum = accountNum
		},
		setDatas(state, datas) {
			state.datas = datas;
		},
		setLang(state, lang) {
			state.lang = lang
		},
	},
	actions: {},
	modules: {},
	plugins: [createPersistedState({
		storage: localStorage
	})]
})
