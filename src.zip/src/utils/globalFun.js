exports.install = function (Vue, options) {
	// 公共方法和属性
	Vue.prototype.$utils = {
		phone_reg: /^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\\d{8}$/ig,
		trim: function (val) { return val.replace(/\s/g, '') },
		laravel_api: 'http://47.75.200.255:8080/api/',
		node_api: 'http://47.75.197.189:3000/',
		socket_api: 'http://jnbadmin.mobile369.com:2120/',
	}
	// 切换主题
	Vue.prototype.$changeTheme = function (type) {
		var head = document.querySelector('head');
		var link = document.querySelector('link#darkTheme');

		var theme = window.localStorage.getItem('theme');
		if (theme != type) {
			window.localStorage.setItem('theme', type);
		}
		if (type == 'light') {
			if (link == null) {
				return;
			} else {
				head.removeChild(link);
				eventBus.$emit('theme', 'light')
			}
		} else {
			if (link == null) {
				link = document.createElement('link');
				link.id = 'darkTheme';
				link.rel = 'stylesheet';
				link.href = './static/theme/dark.css';
				head.appendChild(link);
				eventBus.$emit('theme', 'dark')
			} else {
				return;
			}
		}
	}
	//
	Vue.prototype.$makeSocketId = function () {
		var d = new Date().getTime();
		var ran = parseInt(Math.random() * 888 + 101 + '');
		d = d + '' + ran;
		return d;
	}
	Vue.prototype.isMobile = false
}
