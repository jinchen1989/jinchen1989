import Vue from 'vue'

/***************************** Vue Axios ******************************/
import Axios from "@/http"
import VueAxios from 'vue-axios'
Vue.use(VueAxios, Axios);

/****************************** Global Function ******************************/
import globalFun from '@/utils/globalFun'
Vue.use(globalFun);

/****************************** Vue Filters  ******************************/
import filter from "@/utils/filters"
// register global filters
for (let key in filter) {
	Vue.filter(key, filter[key]);
}

/****************************** VueAwesomeSwiper ******************************/
import VueAwesomeSwiper from 'vue-awesome-swiper'
Vue.use(VueAwesomeSwiper)

/****************************** layer ******************************/
import layer from '../../static/js/layer.js'
Vue.prototype.$layer = layer

/****************************** echarts ******************************/
import echarts from 'echarts'
Vue.prototype.$echarts = echarts

/******************************  ******************************/
let bus = new Vue()
window.eventBus = bus
Vue.prototype.bus = bus

/****************************** VueSocketio ******************************/
// import VueSocketio from 'vue-socket.io'
// Vue.use(VueSocketio, 'http://47.75.200.255:2220/');
// Vue.use(VueSocketio, 'http://47.91.252.4:2220/');

/****************************** Element-ui ******************************/
import { Slider, Input, Row, Col, Button, Form, FormItem, Radio, RadioGroup, Select, Option, Tabs, TabPane, Dialog, Card, Icon, Upload, Carousel, CarouselItem, Pagination, DatePicker, MessageBox, Message, Switch, Progress, Timeline, TimelineItem, Tooltip, Popover } from 'element-ui'
Vue.use(Form)
	.use(FormItem)
	.use(Input)
	.use(RadioGroup)
	.use(Radio)
	.use(Icon)
	.use(Slider)
	.use(Row)
	.use(Col)
	.use(Select)
	.use(Option)
	.use(Button)
	.use(Tabs)
	.use(TabPane)
	.use(Dialog)
	.use(Card)
	.use(Upload)
	.use(Carousel)
	.use(CarouselItem)
	.use(Pagination)
	.use(DatePicker)
	.use(Switch)
	.use(Progress)
	.use(Timeline)
	.use(TimelineItem)
	.use(Tooltip)
	.use(Popover)
