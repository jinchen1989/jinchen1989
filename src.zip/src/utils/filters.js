// export function coinNameFilter(name, lang) {
// 	if (lang == 'zh') {
// 		switch (name) {
// 			case 'BTC':
// 				return '比特币'
// 				break;
// 			case 'ETH':
// 				return '以太坊'
// 				break;
// 			case 'EOS':
// 				return '柚子'
// 				break;
// 			case 'BCH':
// 				return '比特现金'
// 				break;
// 			case 'LTC':
// 				return '莱特币'
// 				break;
// 			case 'ETC':
// 				return '以太经典'
// 				break;
// 			case 'DASH':
// 				return '达世币'
// 				break;
// 			case 'XRP':
// 				return '瑞波币'
// 				break;
// 			case 'BSV':
// 				return '比特币SV'
// 				break;
// 			case 'TRX':
// 				return '波场'
// 				break;
// 			case 'ADA':
// 				return '艾达币'
// 				break;
// 			default:
// 				return ''
// 		}
// 	} else {
// 		switch (name) {
// 			case 'BTC':
// 				return 'bitcoin'
// 				break;
// 			case 'ETH':
// 				return 'Ethereum'
// 				break;
// 			case 'EOS':
// 				return 'EOS'
// 				break;
// 			case 'BCH':
// 				return 'BitcoinCash'
// 				break;
// 			case 'LTC':
// 				return 'LiteCoin'
// 				break;
// 			case 'ETC':
// 				return 'EthereumClassic'
// 				break;
// 			case 'DASH':
// 				return 'DasCoin'
// 				break;
// 			case 'XRP':
// 				return 'Ripple'
// 				break;
// 			case 'BSV':
// 				return 'bBitcoinSV'
// 				break;
// 			case 'TRX':
// 				return 'TRON'
// 				break;
// 			case 'ADA':
// 				return 'ADA'
// 				break;
// 			default:
// 				return ''
// 		}
// 	}
// }

import store from "@/store"

export default {
	coinNameFilter(value) {
		const coinNameList = [
			{ name: "BTC2", name_zh: "比特币", name_en: "bitcoin" },
			{ name: "ETH2", name_zh: "以太坊", name_en: "Ethereum" },
			{ name: "EOS", name_zh: "柚子", name_en: "EOS" },
			{ name: "BCH", name_zh: "比特现金", name_en: "BitcoinCash" },
			{ name: "LTC", name_zh: "莱特币", name_en: "LiteCoin" },
			{ name: "ETC", name_zh: "以太经典", name_en: "EthereumClassic" },
			{ name: "DASH", name_zh: "达世币", name_en: "DasCoin" },
			{ name: "XRP", name_zh: "瑞波币", name_en: "Ripple" },
			{ name: "BSV", name_zh: "比特币SV", name_en: "bBitcoinSV" },
			{ name: "TRX", name_zh: "波场", name_en: "TRON" },
			{ name: "ADA", name_zh: "艾达币", name_en: "ADA" },
		]
		const coin = coinNameList.filter(f => f.name == value)[0]
		if (coin) {
			const key = store.state.lang == "zh" ? "zh" : "en"
			return coin[`name_${key}`]
		}
		return ""
	},
	// 截取当前数据到小数点后五位
	numFilter(value) {
		let transformVal = Number(value).toFixed(5)
		return Number(transformVal)
	}
}
