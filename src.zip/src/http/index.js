import Vue from "vue"
import Axios from "axios"
import vueAxios from "vue-axios"
import Qs from 'qs'
import store from "@/store"

Axios.interceptors.request.use(function (config) {
	config.headers['terminal_type'] = 'pc'; //全局请求添加header
	config.headers['language'] = store.state.lang;
	if (config.url.indexOf('?') === -1) {
		config.url = config.url + '?_timespan=' + +new Date();
	} else {
		config.url = config.url + '&_timespan=' + +new Date();
	}
	// 在发送请求之前做些什么
	return config
}, function (error) {
	// 对请求错误做些什么
	return Promise.reject(error)
})

Axios.interceptors.response.use(function (response) {
	if (response.data.type == '999') {
		// var url = 'admin.dyexchange.com/ad/token?token='+token;
		// this.$http({
		// 	url:'http://admin.dyexchange.com/ad/token?token='+localStorage.getItem('token'),
		// 	method:'get'
		// }).then(res=>{
		// })
		window.localStorage.removeItem("token");
		window.localStorage.removeItem("accountNum");
		window.localStorage.removeItem("user_id");
		window.localStorage.removeItem("extension_code");
		layer.msg('登录超时,请重新登录');
		// setTimeout(function(){
		// 	router.push('/components/login');

		// },2000)
	}
	return response;
}, function (error) {
	return Promise.reject(error);
});
//Axios.defaults.baseURL = ''
// Axios.defaults.headers = { 'Content-Type': 'application/json;charset=UTF-8' }application/x-www-form-urlencoded
// Axios.defaults.withCredentials = true;

Axios.defaults.transformRequest = [(data) => {
	return Qs.stringify(data)
}]

export default Axios
