// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from '@/App'
import router from '@/router'
import i18n from '@/i18n'
import store from '@/store'
import "@/utils" // 外部插件引入
import "@/assets/style/common.scss"

Vue.config.productionTip = false;

//Vue.use(Ws, 'http://test.maxf.pub/users/chatRoom');

new Vue({
	el: '#app',
	i18n,
	router,
	store,
	// components: {
	// 	App
	// },
	// template: '<App/>'
	render: h => h(App)
})
