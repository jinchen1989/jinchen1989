<template>
    <div class="lever">
        <div class="lever-head">
            <span>净资产折合:</span> 
            <span>{{total}} USDT</span>
            <span class="fr ">财务记录</span>
        </div>
        <div class="leverbody contentBK ft12">
            <!-- 合约账户的table表头 -->
            <ul class="titlebox  clearfix">
                <li class="w25" style="text-align:center">可用余额</li>
                <li class="w25 tr" style="text-align:center">冻结余额</li>
                <li class="w25 tr" style="text-align:center">收益余额</li>
                <li class="w25 tr" style="text-align:center">操作</li>
            </ul>
            <!-- 合约账户的table内容 -->
            <ul class="contentbox ">
                <li class="clearfix flex" @click="go_legalAccount()">
                    <p class="w25 l40" style="text-align:center">{{arrangeDetail.balance}}</p>
                    <p class="w25 tr flex column center" style="text-align:center">
                        <span>{{arrangeDetail.lockBalance}}</span>
                    </p>
                    <p class="w25 tr flex column center" style="text-align:center">
                        <span>{{arrangeDetail.interestBalance}}</span>
                    </p>
                    <p class="w25 tr flex column between" style="cursor:pointer;text-align:center">
                        <button class="huazhun">划转</button>
                    </p>
                </li>
            </ul>
        </div>
    </div>
</template>
<script>
import indexHeader from '@/view/indexHeader'
export default {
    name:'lever',
    data(){
        return{
            total:'',
            arrangeDetail: {}
        }
    },
    components:{indexHeader},
    methods:{
        getInfo(){
            let userId = localStorage.getItem('userId')
            this.$http({
                url: '/api/arrange/info/wallet',
                method:'post',
                data:{
                    userId,
                    currencyId: 1
                },
                headers: {'Authorization':  this.token},
            }).then(res=>{
                if(res.data.type == 'ok'){
                    let data = res.data.message
                    let num = this.addNum(data.balance, data.lockBalance)
                    this.total = this.addNum(num, data.interestBalance)
                    this.arrangeDetail = data
                }              
            })
        },
        //进入转币页面
        go_legalAccount(currency_id){
             this.$router.push({
                name:'legalArrange',
                params:{
                }
            })
        },
        addNum (num1, num2) {
            var sq1,sq2,m;
            try {
                sq1 = num1.toString().split(".")[1].length;
            }
            catch (e) {
                sq1 = 0;
            }
            try {
                sq2 = num2.toString().split(".")[1].length;
            }
            catch (e) {
                sq2 = 0;
            }
            m = Math.pow(10,Math.max(sq1, sq2));
            return (num1 * m + num2 * m) / m;
        }
    },
    created(){
        this.token= localStorage.getItem('token') || '';
        console.log(this.address);
        this.getInfo();
    },
    mounted(){
        // this.init();
    }
};
</script>
<style scoped lang="scss">
.huazhun{
    padding: 6px 0;
    background-color: #24a0f5;
    width: 49px;
    border-radius: 7px;
    color: #fff;
    margin: 0 auto;
}
.w25{
    width:25%;
}
.lever{
    height: 820px;
    .lever-head{
        // background-color: #1b1e2e;
        padding: 0 30px;
        height: 48px;
        line-height: 48px;
        font-size: 16px;
        // color: #c7cce6;
        .mincny{
            color: #61688a;
        }
        .filter-input{
                display: inline-block;
                width: 125px;
                height: 28px;
                padding: 0 30px 0 10px;
                background: none;
                border-radius: 3px;
                border: 1px solid #ccc;
        }
    }
    .leverbody{
        padding: 0 20px;
        .titlebox{
            height: 40px;
            line-height: 40px;
            li{
                float: left;
            }
        }
        .contentbox{
            li{
                height: 60px;
                padding:10px;
                border-bottom: 1px solid #ccc;
                >p{
                    float: left;
                    height: 40px;
                }
                .l40{
                    line-height: 40px
                }
                .btn{
                    span{
                        margin-left: 20px;
                        cursor: pointer;
                    }
                    span:hover{
                        color: #61688a
                    }
                }
            }
        }
    }
    .dialog_wrap {
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 9;
        text-align: center;
        // background: rgba(0,0,0,.4);
        .dialog {
            margin-top: 220px;
            display: inline-block;
            width: 560px;
            padding-top: 30px;
            box-sizing: border-box;
            border-radius: 3px;
            text-align: left;
            vertical-align: middle;
            // background-color: #262a42;
            .dia-tit{
                padding: 0 40px 30px;
                font-size: 24px;
                line-height: 24px;
                .close{
                    cursor: pointer;
                }
                .close:hover{
                    // color: #fff
                }
            }
            .dia-content{
                padding: 0 40px;
                margin-bottom: 20px;
                .frombox{
                    height: 48px;
                    line-height: 48px;
                    span{width: 10%}
                    p{
                        height: 48px;
                        padding-left: 20px;
                        line-height: 48px;
                        border-radius: 3px;
                        // background-color: #202437;
                    }
                    .coinimg{
                        width: 28px;
                        margin: 0 auto
                    }
                }
                .dia-coin{
                    // background-color: #202437;
                    p{
                        width: 50%;
                        width: 50%;
                        height: 48px;
                        line-height: 48px;
                        cursor: pointer;
                        position: relative;
                        i{
                            display: none;
                            position: absolute;
                            bottom: 4px;
                            right: 4px;
                            width: 0;
                            height: 0;
                            border: 6px solid transparent;
                            border-right: 6px solid #fff;
                            border-bottom: 6px solid #fff;
                        }
                    }
                    .select{
                        color: #fff;
                        background-color: #7a98f7;
                        i{
                            display: block
                        }
                    }
                    p:first-child{
                        border-radius: 3px 0 0 3px;
                    }
                    p:last-child{
                        border-radius: 0 0px 3px 0;
                    }
                } 
                .inputboxs{
                    width: 100%;
                    border-radius: 3px;
                    // background-color: #1e2235;
                    border: 1px solid #ccc;
                    padding: 0 20px;
                    input{
                        background: transparent;
                        height: 46px;
                        // color: #fff

                    }
                    span{
                        margin-left: 15px
                    }
                    .all{
                        color: #ff7519;
                        cursor: pointer;
                    }
                }
                .btn-box{
                    margin: 50px 0;
                    div{
                        width: 50%;
                        height: 48px;
                        line-height: 48px;
                        margin: 0 10px;
                        border-radius: 3px;
                        cursor: pointer;
                    }
                    .sure{
                        color: #fff;
                        background: #7a98f7;
                    }
                }
                
            }
        }
            
    }
}
</style>


