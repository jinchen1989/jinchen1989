<template>
    <div class="main   clr-part">
        <div class="legalAccount_msg flex between bg-part" style="padding:20px 30px">
          <div>
              <p class="ft12 msg_title">币币可用余额</p>
              <p style="color:#EF5E41">{{ rankingItem.userChangeWallet }}</p>
          </div>
          <div>
              <p class="ft12 msg_title">理财可用余额</p>
              <p style="color:#4A95F1">{{ rankingItem.arrangeWalletActive }}</p>
          </div>
          <div>
              <p class="ft12 msg_title">理财利息余额</p>
              <p style="color:#2EDB99">{{ rankingItem.arrangeWalletInterest }}</p>
          </div>
        </div>
        <div class="transfer bg-part" style="margin-top:20px;padding:20px 30px">
            <div class="direction flex">
                <select name="" id="" style="padding:3px 16px" ref="select" v-model="turn" @change="turnChange">
                    <option v-for="(item, index) in selectData" :key="index" :value="index">{{ item }}</option>
                </select>
                <img src="../../assets/images/transfer2.png" alt="">
                <div>{{ turnName[index] }}</div>
            </div>
            <div class="flex">
                <span>币种：</span>
                <p>USDT</p>
            </div>
            <div class="flex">
                <span>{{$t('account.huanum')}}：</span>
                <input type="numer" v-model="number">
            </div>
            <button class="blue_bg" type="button" @click="transfer">{{$t('account.transfer')}}</button>
        </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
      rankingItem: {},
      coins: [],
      number: '',
      turn: 0,
      index: 0,
      selectData:[
        '币币',
        '理财',
        '收益'
      ],
      turnName: [
        '理财',
        '币币'
      ],
      type: 1
    };
  },
  created() {
    this.token = localStorage.getItem("token") || "";
    if(this.token){
      this.init();
      this.getCoins();
    }
  },
  mounted() {
    
  },
  methods: {
    turnChange() {
      let turn = this.turn
      if(turn == 0) {
        this.index = 0
        this.type = 1
      }else if(turn == 1){
        this.index = 1
        this.type = 2
      }else{
        this.index = 0
        this.type = 3
      }
    },
    getCoins() {
      var load = layer.load();
      this.token = window.localStorage.getItem("token") || "";
      this.$http({
        url: "/api/wallet/info",
        method: "get",
        headers: { Authorization: this.token }
      }).then(res => {
        layer.close(load);
        if (res.data.type == "ok") {
          this.coins = res.data.message.legal.balance;
        }
      });
    },
    init() {
      var load = layer.load();
      let params = {
        userId: localStorage.getItem('userId'),
        currencyId: 1
      }
      this.$http({
          url: '/api/arrange/info/walletAll',
          method:'post',
          params,  
          headers: {'Authorization':  localStorage.getItem('token')},    
      }).then(res=>{
              if(res.data.type == 'ok') {
                layer.close(load);
                this.rankingItem = res.data.message
              }else {
                layer.close(load);
                layer.msg(res.data.message) 
              }
            
      }).catch(error=>{
            
      })     
    },
    // 划转
    transfer(){
      let { number, type } = this
      if(!number) {
        layer.msg('请输入划转数量!') 
        return false
      }
      if(number<= 0) {
        layer.msg('划转数量必须大于0!') 
        return false
      }
      let params = {
        number,
        type,
        currency_id: 1
      }
      this.$http({
        url: '/api/wallet/transfer',
        method:'post',
        params,  
        headers: {'Authorization':  localStorage.getItem('token')},    
      }).then(res=>{
        if(res.data.type == 'ok') {
          this.number = ''
          this.init()
          layer.msg(res.data.message) 
        }else {
          layer.msg(res.data.message) 
        }
      }).catch(error=>{
          
      })     
    }
  }
};
</script>
<style scoped lang='scss'>
  .lock{
    padding-bottom: 5px;
  }
  .actives{
    border-bottom: 2px solid #d45858;
    color: #d45858;
  }
  .legal_name {
    /* background: #1b1e2e; */
    padding: 5px 0;
  }
  .msg_title {
    /* color: #61688a; */
  }
  .main {
  }
  .transfer .flex {
    margin: 16px 0;
    line-height: 40px;
    span {
      // width: 100px;
    }
    select {
      border-radius: 2px;
      border:none;
      background: #fff5dc;
    }
    input {
      padding: 0 14px;
      border-radius: 2px;
      line-height: 39px;
      border: 1px solid #ccc;
    }
  }
  .transfer button {
    padding: 10px 60px;
    background: #563bd1;
    color: #fff;
    border-radius: 2px;
    margin-top: 20px;
  }
  .direction {
    padding: 0 20px;
    line-height: 44px;
    background: #fff5dc;
    margin-top: 10px !important;
    img {
      margin: 0 44px;
      cursor: pointer;
    }
  }
  .legalAccount_msg {
    /* background: #1b1e2e; */
    padding: 6px 0;
  }
  .legalAccount_msg div p:first-child {
    margin-bottom: 10px;
    font-size: 18px;
  }
  .legalAccount_msg div p:last-child {
    font-size: 24px;
  }
  .rec_wrap {
    margin-top: 20px;
    margin-bottom: 30px;
  }

  .all {
    /* color: #61688a; */
  }
  .list_title {
    padding: 10px 0;
    /* background: #1b1e2e; */
  }
  .huazhuan {
    text-align: center;
    margin-top: 60px;
    background: #d45858;
    padding: 8px;
  }
  .huazhuan:hover {
    cursor: pointer;
  }
  .ptb {
    padding: 8px 0;
  }
  .no_rec {
    cursor: pointer;
  }
  .log_wrap {
    height: 480px;
    overflow: auto;
    border: 1px solid #ededed;
  }
  .log_wrap::-webkit-scrollbar {
    /*滚动条整体样式*/
    width: 2px; /*高宽分别对应横竖滚动条的尺寸*/
    height: 8px;
  }
  .log_wrap::-webkit-scrollbar-thumb {
    /*滚动条里面小方块*/
    border-radius: 10px;
    -webkit-box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
    background: #9e9898;
  }
  .log_wrap::-webkit-scrollbar-track {
    /*滚动条里面轨道*/
    -webkit-box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
    border-radius: 10px;
    background: #ededed;
  }
</style>
