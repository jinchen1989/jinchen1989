<template>
  <div class="download-page">
    <index-header></index-header>
    <div class="download">
      <img src="@/assets/images/bg_downpage.jpg" alt />
      <div class="title">
        <h1>{{$t("home.c12")}}</h1>
        <p>{{$t("home.c13")}}</p>
      </div>
      <div class="link">
        <p>
          <img src="@/assets/images/icon_ios.png" alt />
          <span>iPhone</span>
          <span>
            <a href target="blank">{{$t('download.text')}}</a>
          </span>
        </p>
        <p>
          <img src="@/assets/images/icon_android.png" alt />
          <span>Android</span>
          <span>
            <a href target="blank">{{$t('download.text')}}</a>
          </span>
        </p>
      </div>
    </div>
  </div>
</template>

<script>
import indexHeader from "@/view/indexHeader";
export default {
  name: "App",
  components: {
    indexHeader,
  },
  data() {
    return {};
  },
};
</script>

<style scoped lang="scss">
.download-page {
  width: 100%;
  height: calc(100vh - 267px);
  .download {
    height: 100%;
    position: relative;
    & > img {
      width: 100%;
      min-height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      z-index: 1;
    }
    .title {
      text-align: center;
      position: relative;
      top: 40px;
      z-index: 2;
      h1 {
        font-size: 30px;
        font-weight: 700;
      }
      p {
        font-size: 20px;
        margin-top: 20px;
      }
    }
    .link {
      width: 316px;
      height: 160px;
      position: absolute;
      top: calc(50% - 40px);
      left: 60%;
      right: 100px;
      z-index: 2;
      p {
        img {
          display: inline-block;
          width: 80px;
          height: 80px;
          margin-right: 10px;
        }
        span {
          display: inline-block;
          margin-right: 10px;
          font-size: 20px;
          line-height: 80px;
          color: #000;
        }
      }
    }
  }
}
</style>
