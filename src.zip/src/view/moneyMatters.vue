<template>
	<div class="wrap moneyMatters">
		<div :style="{height:bannerHeight + 'px'}">
			<el-carousel :interval="3000" arrow="never" :height="bannerHeight + 'px'">
				<el-carousel-item v-for="(item,index) in banner_imgs" :key="item.id" class=" hidden">
					<span class="block"
						  :style="{background: 'url(' + item.pic + ')', backgroundSize:'100% 100%',height:bannerHeight + 'px',width:'100%'}"></span>
				</el-carousel-item>
			</el-carousel>
		</div>
		<div class="msgList">
			<img class="tips" src="../../static/imgs/tips.png">
			<img class="msg" src="../../static/imgs/msg.png">
			<div class="box">
				<div class="my-outbox">
			        <div class="my-inbox" ref='box'>
			            <div class="my-list" v-for="(item,index) in send" :key='index' ref='list'>
			                {{item.notice}}
			            </div>
			        </div>
			    </div>
			</div>
		</div>
		<div class="iconList">
			<div class="contents">
				<div class="list">
					<div class="listTitle">
						{{ walletDetail.grade }}
					</div>
					<div class="item" v-for="(item, index) in list" :key="index"  @click.stop="seeDetail(item, index)">
						<img :src="item.image">
						<div class="name">{{ item.name }}</div>
						<div class="money">{{ item.money }}</div>
					</div>
					<div class="item_detail" v-if="detailShow">
			      		<div class="closeBtn" @click.stop="detailShow = false"></div>
			      		<div class="DetailList">
			      			<div class="top">
			      				<div>类型</div>
			      				<div>数量</div>
			      				<div>时间</div>
			      			</div>
			      			<div v-if="detailList.length">
				      			<div class="item" v-for="(item, index) in detailList" :key="index">
				      				<div>{{ item.type | earningsData }}</div>
				      				<div> +{{ item.numbers }}{{ item.currencyName }}</div>
				      				<div>{{ item.createTime | dataTime }}</div>
				      			</div>
				      		</div>
				      		<div v-else>
				      			<div class="noList">暂无历史</div>
				      		</div>
			      		</div>
			      	</div>
				</div>
			</div>
		</div>
		<div class="iconList swiper">
			<div class="contents">
				<div class="swiper-container">
				    <div class="swiper-wrapper">
				      	<div class="swiper-slide" v-for="(item, indexs) in mattersList" :key="indexs">
				      		<block v-if="item.period">
						      	<div class="title">{{ item.name }}第{{ item.period  }}期</div>
						      	<div class="rushBuy">
						      		<div class="progress">
						      			<div class="percentage" :style="{ width: item.reservationNum/item.numbers*100 + '%' }"></div>
						      		</div>
						      		<div class="status">{{ item.status | statusFilter}}</div>
						      	</div>
						      	<div class="profit">
						      		<div class="top">日收益率</div>
						      		<div class="profit_num">≈{{ item.interest }}%</div>
						      		<div class="profitList">
						      			<div class="item">
						      				<div class="num">{{ item.minBuy }}-{{ item.maxBuy }}</div>
						      				<div class="text">理财份数(份)</div>
						      			</div>
						      			<div class="item">
						      				<div class="num">{{ item.stock }}</div>
						      				<div class="text">剩余数量(份)</div>
						      			</div>
						      			<div class="item">
						      				<div class="num">{{ item.timing *30 }}</div>
						      				<div class="text">理财期限(天)</div>
						      			</div>
						      		</div>
						      	</div>
						      	<div class="payBox">
						      		<div style="width:30px;">¥</div>
						      		<div @click.stop="inputClick()" style="width:100%;">
						      			<input type="number" :placeholder="item.minBuy + '-' + item.maxBuy" v-model="item.value" @input="valueInput(item.value)" :disabled="item.status !== 1">
						      		</div>
						      		<div class="company">份</div>
						      	</div>
						      	<div class="tips">注:本期理财不可重复购买,全部出售完后一天开始计算收益。</div>
						      	<button class="myBtn" :class="[ item.status !== 1? 'disabledBtn': '']" @click.stop="payMatters(item, index)" :disabled="item.status !== 1">{{ item.status !== 1?'已结束': '立即投资' }}</button>
						      	<div class="swiper_bottom" v-if="item.status == 1">
						      		<input :id="'agree' + indexs" class="aggre" :value="indexs" v-model="checkedValue" @change="checks(indexs)" type="checkbox" :disabled="item.status !== 1" />
						      		<label :for="'agree' + indexs" @click.stop="checks(indexs)"> 
						      			同意
						      			<router-link to="/aggrement" class="link_text">相关协议</router-link>,
						      			并知晓页面展示收益率不代表收益承诺.
						      		</label>
						      	</div>
						      	<!-- <div class="item_bg" v-if="item.status !== 1">
						      		暂未开启 敬请期待
						      	</div> -->
						    </block>
						    <div v-else class="noData">
						    	<img :src="item.nodata">
						    </div>
				     	</div>
				    </div>
				    <!-- 如果需要导航按钮 -->
				    <!-- <div class="btn_left"> -->
				    	<div class="swiper-button-prev"></div>
				    <!-- </div> -->
				    <!-- <div class="btn_right"> -->
				    	<div class="swiper-button-next"></div>
				    <!-- </div> -->
				</div>
			</div>
		</div>
		<div class="myMoney">
			<div class="contents">
				<div class="myMoney_left">
					<div class="title">理财排行</div>
					<div class="rankingList">
						<div class="top">
							<div>用户&nbsp;&nbsp;&nbsp;&nbsp;</div>
							<div>金额</div>
							<div>排名</div>
						</div>
						<div class="rankingItem" v-for="(item, index) in rankingItem" :key="index">
							<div>{{ item.account }}</div>
							<div>{{ item.num }}</div>
							<div v-if="index == 0"><img  src="../../static/imgs/no1.png">NO.{{ index + 1 }}</div>
							<div v-else-if="index == 1"><img src="../../static/imgs/no2.png">NO.{{ index + 1 }}</div>
							<div v-else-if="index == 2"><img src="../../static/imgs/no3.png">NO.{{ index + 1 }}</div>
							<div v-else>NO.{{ index + 1 }}</div>
						</div>
					</div>
				</div>
				<div class="myMoney_right">
					<div class="title">我的理财</div>
					<div class="mattersList" v-if="!rankingDetailShow">
						<div class="item" v-for="(item, index) in rankingItems" :key="index" @click="rankingDetail(item)">
							<div class="img">
								<img src="../../static/imgs/img2.png">
							</div>
							<div class="DailydIncome">
								<div class="label">日收益率</div>
								<div class="day_num">≈{{item.interest}}%</div>
							</div>
							<div class="stage">
								<div class="label">{{ item.arrangeName }}{{ item.period  }}期</div>
								<div class="day">
									<div>{{ item.timing }}月</div>
									<div>{{ item.numbersAll }}USDT</div>
								</div>
							</div>
							<div class="status">
								<div class="label">{{ item.status == 0?'已结束': '进行中' }}</div>
								<div class="time">{{ item.createTime | dataTime }}</div>
							</div>
						</div>
					</div>
					<div class="mattersDetail" v-else>
						<div class="cancel" @click="rankingDetailShow = false"></div>
						<div class="matterTiTle">米图开盘新标第{{ rankingDetails.period }}期</div>
						<div class="matterContent">
							<div>日收益率 ≈{{ rankingDetails.interest }}%</div>
							<div>理财期限(月) {{ rankingDetails.timing }}</div>
						</div>
						<div class="matterInfo">
							<div class="text">理财金额</div>
							<div class="num">{{ rankingDetails.numberAll }}</div>
							<div class="item">
								<div>状态</div>
								<div class="status">{{ rankingDetails.status == 1?'已结束': '进行中' }}</div>
							</div>
							<div class="item">
								<div>累计收益</div>
								<div>{{ rankingDetails.interestAll }}USDT</div>
							</div>
							<div class="item">
								<div>理财时间</div>
								<div>{{ rankingDetails.createTime | dataTime }}</div>
							</div>
						</div>
						<button  :class="[ rankingDetails.status !== 1? 'disabledBtn': '']" :disabled="rankingDetails.status !== 1" class="cancelBtn" @click="cancelPay(rankingDetails)">取消理财</button>
					</div>
				</div>
			</div>
		</div>
		<div class="myFlexs" @click.stop="seeDetail(2)">
			<img src="../../static/imgs/flexImg.png"></img>
		</div>
	</div>
</template>

<script type="text/javascript">
	import marqueeLeft from '@/components/marquee'
	import Swiper from "swiper";
	import "swiper/dist/css/swiper.min.css";
	import { MessageBox } from 'element-ui';
	export default {
		components: { marqueeLeft},
		filters: {
		    statusFilter(status) {   //根据状态值显示不同类型的按钮样式
		     	const statusMap = [
		        	'已结束',
		        	'抢购中',
		        	'理财中',
		        	'未开启'
		      	]
		      	return statusMap[status]
		    },
		    earningsData(status) {
		    	const earningsStatus = [
		    		'理财直推奖',
		    		'理财分红奖'
		    	]
		    	return earningsStatus[status - 3]
		    },
		    dataTime(time) {
		    	return time.slice(0, 10)
		    }
		},
		data() {
			return{
				isCheck: '',
				checkedValue: [],
				detailShow: false,
				bannerHeight: 492,
				bannerWidth: '',
				screenWidth: window.innerWidth,
				banner_imgs:[],
				send:[],
	            list: [
	            	{
	            		name: '总资产(USDT)',
	            		image: '../../static/imgs/icon1.png',
	            		money: '0.00'
	            	},
	            	{
	            		name: '可用(USDT)',
	            		image: '../../static/imgs/icon2.png',
	            		money: '0.00'
	            	},
	            	{
	            		name: '冻结(USDT)',
	            		image: '../../static/imgs/icon3.png',
	            		money: '0.00'
	            	},
	            	{
	            		name: '收益(USDT)',
	            		image: '../../static/imgs/icon4.png',
	            		money: '0.00'
	            	}
	            ],
	            mattersList: [
	            	{
	            		nodata: '../../static/imgs/noList.png'
	            	},
	            	{
	            		nodata: '../../static/imgs/noList.png'
	            	},
	            	{
	            		nodata: '../../static/imgs/noList.png'
	            	}
	            ],
	            usdtNum: '',
	            nowTime:null,//定时器标识
                disArr:[],//每一个内容的宽度,
                rankingItem: [],
                rankingItems: [],
                detailList: [],
                rankingDetailShow: false,
                rankingDetails: {},
                walletDetail: {}
			}
		},
		watch: {
			screenWidth(val) {
				this.bannerWidth = val
				if (val > 1560) {

					this.bannerHeight = 492
				}
				if (val < 1560) {
					this.bannerHeight = 400
				}
			}
		},
		beforeDestroy:function(){
            clearInterval(this.nowTime);//页面关闭清除定时器
            this.nowTime = null;//清除定时器标识
        },
		mounted() {
			window.onresize = () => {
				return (() => {
					window.screenWidth = window.innerWidth
					this.screenWidth = window.screenWidth;
				})()
			}
			new Swiper ('.swiper-container', {
				// autoplay: 5000,	//可选选项，自动滑动
        		pagination: '.swiper-pagination',         
        		nextButton: '.swiper-button-next',
        		prevButton: '.swiper-button-prev',
        		slidesPerView : 3,
				spaceBetween : 0      
      		})
		},
		mount: function () {
		},
		created() {
			let userId = localStorage.getItem('userId')
			this.getNotice() 
			this.getBanner()
			if(userId) {
				this.getWallet(userId)
			}
			this.getRank()
			this.getList()
			this.getOrder()
		},
		methods:{
			inputClick() {},
			valueInput(e) {
				this.usdtNum = e
			},
			checks(index) {
				this.isCheck = index
			},
			payMatters(e, index) {
				console.log(this.checkedValue)
				let userId = localStorage.getItem('userId')
				let number = this.usdtNum
				let arrangeId = e.id
				let isCheck = this.isCheck
				if(this.checkedValue.indexOf(isCheck) == -1) {
					layer.msg('请同意相关协议!')
					return false;
				}  
				if(!number) {
					layer.msg('请输入购买数量!')
					return false;
				} 
				let params = {
					userId,
		        	number,
		        	arrangeId
				}
				this.$http({
			        url: 'api/arrange/buy',
			        method:'GET',
			        params,
			        headers: {'Authorization':  localStorage.getItem('token')},    
			    }).then(res=>{
			        if(res.data.type == 'ok') {
			        	this.getOrder()
			        	layer.msg(res.data.message)
			        }else{
			        	layer.msg(res.data.message)
			        }
			    }).catch(error=>{
			    })        
			},
			//获取margin属性
            getMargin:function(obj){
                var marg = window.getComputedStyle(obj,null)['margin-right'];
                marg = marg.replace('px','')
                return Number(marg) //强制转化成数字
            },
            //移动的方法
            moveLeft:function(){
                var outbox = this.$refs.box;
                var that=this;
                var startDis = 0;//初始位置
                this.nowTime = setInterval(function(){
                    startDis -= 0.5;
                    if(Math.abs(startDis) > Math.abs(that.disArr[0])){
                        that.disArr.push(that.disArr.shift())//每次移动完一个元素的距离，就把这个元素的宽度
                        that.send.push(that.send.shift())//每次移动完一个元素的距离，就把列表数据的第一项放到最后一项
                        startDis = 0;
                    }
                    outbox.style = 'transform: translateX('+ startDis +'px)'; //每次都让盒子移动指定的距离
                },1000/60)
            },
			getBanner() {
				this.$http({
			        url: '/api/arrange/show/list',
			        method:'get',
			        data:{},  
			        headers: {'Authorization':  localStorage.getItem('token')},    
			    }).then(res=>{
			          if(res.data.type == 'ok') {
			          	this.banner_imgs = res.data.message
			          }
			          
			    }).catch(error=>{
			          
			    })        
			},
			getNotice() {
				var load = layer.load();
				this.$http({
			        url: '/api/arrange/info/notice',
			        method:'get',
			        data:{},  
			        headers: {'Authorization':  localStorage.getItem('token')},    
			    }).then(res=>{
			          if(res.data.type == 'ok') {
			          	this.send = res.data.message
			          	this.$nextTick(()=> {
			                var that = this;
			                var item = that.$refs.list; 
			                var len = that.send.length;
			                var arr = [];
			                var margin = that.getMargin(item[0]) //因为设置的margin值一样，所以取第一个就行。
			                for(var i = 0;i < len;i++){
			                    // arr.push(item[i].clientWidth + margin)//把宽度和 margin 加起来就是每一个元素需要移动的距离
			                    arr.push(item[i].clientWidth)//把宽度和 margin 加起来就是每一个元素需要移动的距离
			                }
			                that.disArr = arr;
			                that.moveLeft();
			                
			            })
			          }
			          layer.close(load);
			    }).catch(error=>{
			          
			    })        
			},
			getWallet(userId) {
				this.$http({
			        url: '/api/arrange/info/wallet',
			        method:'post',
			        data:{
			        	userId,
			        	currencyId: 1
			        },  
			        headers: {'Authorization':  localStorage.getItem('token')},    
			    }).then(res=>{
			          	if(res.data.type == 'ok') {
			          		let data = res.data.message
			          		this.list[1].money = data.balance
			          		this.list[2].money = data.lockBalance
			          		this.list[3].money = data.interestBalance
			          		let num = this.addNum(data.balance, data.lockBalance)
			          		this.list[0].money = this.addNum(data.interestBalance, num)
			          		this.walletDetail = data
			          	}
			          
			    }).catch(error=>{
			          
			    })       
			},
			addNum (num1, num2) {
	       		var sq1,sq2,m;
	       		try {
	         		sq1 = num1.toString().split(".")[1].length;
	       		}
	       		catch (e) {
	          		sq1 = 0;
	        	}
	       		try {
	          		sq2 = num2.toString().split(".")[1].length;
	       		}
	        	catch (e) {
	         		sq2 = 0;
	        	}
	        	m = Math.pow(10,Math.max(sq1, sq2));
	        	return (num1 * m + num2 * m) / m;
	      	},
	      	getRank() {
	      		this.$http({
			        url: '/api/arrange/info/rank',
			        method:'get',
			        data:{},  
			        headers: {'Authorization':  localStorage.getItem('token')},    
			    }).then(res=>{
			          	if(res.data.type == 'ok') {
			          		this.rankingItem = res.data.message
			          	}
			          
			    }).catch(error=>{
			          
			    })     
	      	},
	      	getListHistory(data) {
	      		this.$http({
			        url: '/api/arrange/info/list_history',
			        method:'get',
			        data:{},  
			        headers: {'Authorization':  localStorage.getItem('token')},    
			    }).then(res=>{
			          	console.log(res.data.message)
			          	if(res.data.message == '暂无历史数据!') {
			          		if(data) {
			          			data.value = ''
				          		this.mattersList.splice(1, 1, data)
				          		console.log(this.mattersList)
			          		}
			          	}else if(res.data.message.length  == 1) {
			          		data.value = ''
			          		res.data.message[0].value = ''
				          	this.mattersList.splice(0, 1, res.data.message[0])
				          	this.mattersList.splice(1, 1, data)
			          	}else if(res.data.message.length  == 2) {
			          		data.value = ''
			          		res.data.message[0].value = ''
			          		res.data.message[1].value = ''
				          	this.mattersList.splice(0, 1, res.data.message[0])
				          	this.mattersList.splice(2, 1, res.data.message[1])
				          	this.mattersList.splice(1, 1, data)
			          	}else if(res.data.message.length  >= 3) {
			          		res.data.message.splice(1, 0, data)
			          		res.data.message.map(n => {
			          			n.value = ''
			          		})
			          		this.mattersList = res.data.message
			          	}
			    }).catch(error=>{
			          
			    })     
	      	},
	      	getList() {
	      		this.$http({
			        url: '/api/arrange/info/list',
			        method:'get',
			        data:{},  
			        headers: {'Authorization':  localStorage.getItem('token')},    
			    }).then(res=>{
			          	if(res.data.type == 'ok') {
			          		this.getListHistory(res.data.message)
			          	}
			          
			    }).catch(error=>{
			          
			    })       
	      	},
	      	seeDetail(e, index) {
	      		let userId = localStorage.getItem('userId')
      			let params = {
      				userId
      			}
      			if(e.name == '收益(USDT)' || e == '2') {
      				this.$http({
				        url: `/api/arrange/info/earnings`,
				        method:'get',
				        params,
				        headers: {'Authorization':  localStorage.getItem('token')},    
				    }).then(res=>{
			          	if(res.data.type == 'ok') {
			          		this.detailList = res.data.message
			          		this.detailShow = true
			          	}
				    }).catch(error=>{
				          
				    })     
      			}
	      	},
	      	getOrder() {
	      		let userId = localStorage.getItem('userId')
      			this.$http({
			        url: `/api/arrange/info/order`,
			        method:'post',
			        data: {
			        	userId
			        },
			        headers: {'Authorization':  localStorage.getItem('token')},    
			    }).then(res=>{
		          	if(res.data.type == 'ok') {
		          		this.rankingItems = res.data.message
		          	}
			    }).catch(error=>{
			          
			    })     
	      	},
	      	rankingDetail(e) {
	      		let userId = localStorage.getItem('userId')
				let arrangeId = e.arrangeId 
				let params = {
					userId,
			        arrangeId
				}
				this.$http({
			        url: `/api/arrange/detail/arrange`,
			        method:'get',
			        params,
			        headers: {'Authorization':  localStorage.getItem('token')},    
			    }).then(res=>{
		          	if(res.data.type == 'ok') {
		          		this.rankingDetails = res.data.message
		          		this.rankingDetailShow = true
		          	}
			    }).catch(error=>{
			          
			    })    
	      	},
	      	cancelPay(e) {
	      		MessageBox.confirm('此操作将取消该产品, 是否继续?', '提示', {
		          	confirmButtonText: '确定',
		          	cancelButtonText: '取消',
		          	type: 'warning'
		        }).then(() => {
		        	let userId = localStorage.getItem('userId')
					let orderId = e.id 
					let params = {
						userId,
				        orderId
					}
		        	this.$http({
				        url: `/api/arrange/cancel`,
				        method:'get',
				        params,
				        headers: {'Authorization':  localStorage.getItem('token')},    
				    }).then(res=>{
			          	if(res.data.type == 'ok') {
			          		layer.msg(res.data.message) 
			          		this.getOrder()
			          		this.rankingDetailShow = false
			          	}else{
			          		layer.msg(res.data.message) 
			          		this.rankingDetailShow = false
			          	}
				    }).catch(error=>{
				          
				    })    
		        }).catch(() => {
		          	layer.msg('已取消!')      
		        });
	      	}
		}
	}
</script>

<style lang='scss' scoped>
	.el-progress-bar__inner{
		background: linear-gradient(#5702FB, #9925EB);
	}
	.btn_left{
		width:38px;
		height:38px;
		background: #181B29;
		border-radius: 50%;
		position: absolute;
		top: 50%;
		left: 390px;
		text-align: center;
		line-height:38px;
		z-index: 100000;
		.swiper-button-prev{
			position: initial;
			width:25px;
			height:25px;
			margin: 0 auto;
			vertical-align: middle;
			margin-top:5px;
			background-size: 14px 25px;
		}
	}
	.btn_right{
		width:38px;
		height:38px;
		background: #181B29;
		border-radius: 50%;
		position: absolute;
		top: 50%;
		right: 390px;
		text-align: center;
		line-height:38px;
		z-index: 100000;
		.swiper-button-next{
			position: initial;
			width:25px;
			height:25px;
			margin: 0 auto;
			vertical-align: middle;	
			margin-top:5px;
			background-size: 14px 25px;
		}
	}
	.moneyMatters{
		min-height: 1080px;
		background:#181B29;
		.msgList{
			background: #272A3A;
			display: flex;;
			flex-direction: row;
			align-items: center;
			padding: 15px 20px;
			margin-bottom:80px;
			.msg{
				width:26px;
				height: 24px;
			}
			.tips{
				width: 138px;
				height: 30px;
			}
			.box{
				overflow: hidden;	
			}
			.tipList{
				display: flex;;
				flex-direction: row;
				align-items: center;
				p{
					white-space:nowrap;
					font-size:16px;
					color:#fff;
					letter-spacing: 2px;
				}
			}
		}
		.iconList{
			background: #272A3A;
			margin-bottom:80px;
			.contents{
				width:1200px;
				margin:0 auto;
				padding: 69px 67px 45px;
				.list{
					display:flex;
					justify-content: space-between;
					text-align: center;
					position: relative;
					img{
						width:115px;
						height:115px;
						margin-bottom:10px;
					}
					.name{
						font-size:18px;
						color:#fff;
						line-height:20px;
						margin-bottom:9px;
					}
					.money{
						font-size:20px;
						color:#3EA9FF;
						line-height:17px;
					}
					.listTitle{
						width:112px;
						height:33px;
						border: 1px solid #fff;
						border-radius: 10px;
						line-height:33px;
						text-align: center;
						font-size:18px;
						color:#fff;
						position: absolute;
						left: 50%;
						top:-34px;
						margin-left: -56px;
					}
					.item_detail{
						width:354px;
						height: 446px;
						position: fixed;
						right:10%;
						top:10%;
						background: url(../../static/imgs/model.png)no-repeat center;
						background-size: 100% 100%;
						border-radius: 10px;
						padding: 129px 50px 50px;
						color:#333333;
						z-index:100000;
						.closeBtn{
							width:20px;
							height:20px;
							background: url(../../static/imgs/close.png)no-repeat center;
							background-size: 100% 100%;
							position: absolute;
							top:10px;
							left:10px;
						}
						.top{
							display: flex;
							text-align: left;
							border-bottom: 1px solid #333333;
							padding-bottom:11px;
							div{
								flex: 1;
								font-size: 16px;
								font-weight: 400;
							}
						}
						.DetailList{
							height:260px;
							overflow-y: auto;
						}
						.noList{
							margin-top: 30px;
						}
						.item{
							height:33px;
							line-height:33px;
							text-align: left;
							display: flex;
							border-bottom: 1px solid #333333;
							&:last-child{
								border-bottom:none;
							}
							div{
								flex: 1;
								font-size:14px;
							}
						}
					}
				}
			}
		}
		.swiper{
			margin-bottom:0;
			.contents{
				width:1330px;
				padding: 0;
			}
		}
		.swiper-container{
			.swiper-slide{
				position: relative;
				width:461px;
				height: 511px;
				background:#133149;
				border-radius: 30px;
				margin:100px auto;
				transform:scale(.7,.7);
				padding: 10px;
				color:#fff;
				.item_bg{
					position: absolute;
					width:100%;
					height:100%;
					background: rgba(225, 225, 225, .8);
					left:0;
					top:0;
					right:0;
					bottom:0;
					border-radius: 30px;
					text-align: center;
					padding-top: 200px;
					font-size:30px;
					color:#E3283E;
				}
				.title{
					font-size:16px;
					text-align: center;
					padding: 10px 0;
					border-bottom: 1px solid #181B29;
				}
				.rushBuy{
					display:flex;
					justify-content: space-between;
					margin: 17px 0;
					align-items: center;
					.progress{
						width:100%;
						height: 11px;
						background:#fff;
						border-radius: 30px;
						position: relative;
						.percentage{
							position: absolute;
							left:0;
							top:0;
							width: 60%;
							height: 100%;
							border-radius: 30px;
							background: linear-gradient(to right, #5802FB, #9C28EB);
						}
					}
					.status{
						font-size:14px;
						color:#fff;
						margin-left:10px;
						width:70px;
						text-align: right;
					}
				}
				.profit{
					border: 1px solid #181B29;
					border-radius: 10px;
					padding: 27px 22px;
					margin-bottom:18px;
					.top{
						font-size:14px;
						text-align: center;
						line-height:17px;
					}
					.profit_num{
						font-size:30px;
						color:#E3283E;
						margin:32px auto 25px;
						text-align: center;
						line-height:24px;
					}
					.profitList{
						display: flex;
						justify-content: space-between;
						.item{
							text-align: center;
							.num{
								font-size:14px;
								margin-bottom: 6px;
							}
							.text{
								font-size:14px; 
								color:#E3283E;
							}
						}
					}
				}
				.payBox{
					border: 1px solid #181B29;
					border-radius: 30px;
					padding: 13px 21px;
					display: flex;
					justify-content: space-between;
					font-size:21px;
					color:#fff;
					input{
						background: #133149;
						::-webkit-input-placeholder {
					        color: #344B60;
					    }
					}
					.company{
						color:#344B60;
					}
				}
				.tips{
					margin: 9px auto 17px;
					font-size:12px;
					color:#344B60;
					line-height:13px;
					text-align: center;
				}
				.myBtn{
					width:100%;
					height:52px;
					font-size:16px;
					background:linear-gradient(to right, #9929EA, #5808FB);
					border-radius: 15px;
					color:#fff;
					margin-bottom:15px;
				}
				.disabledBtn{
					background:#999;
				}
				.swiper_bottom{
					text-align: center;
					font-size:10px;
					line-height:11px;
					.aggre{
						width:15px;
						height:15px;
						border-radius: 50%;
						vertical-align: middle;
					}
					.link_text{
						color:#E3283E;
					}
				}
			}
			.swiper-slide.swiper-slide-next {
				transform:scale(1,1);
			}
		}
		.myMoney{
			padding: 80px 0;
			.contents{
				width:1200px;
				margin:0 auto;
				display: flex;
				justify-content: space-between;
				.myMoney_left,.myMoney_right{
					width:580px;
					background:#272A3A;
					text-align: center;
					padding: 20px 0;
					color:#fff;
					.title{
						width:112px;
						height:33px;
						border-radius: 10px;
						border:1px solid #fff;
						line-height:33px;
						font-size:16px;
						margin: 0 auto 20px;
					}
					.mattersDetail{
						border-top: 1px solid #181B29;
						position: relative;
						padding: 0 30px;
						.cancel{
							position: absolute;
							left:10px;
							top:10px;
							width:30px;
							height:30px;
							background:url(../../static/imgs/cancel.png)no-repeat center;
							background-size: 100% 100%;
						}
						.matterTiTle{
							margin:20px auto;
							width:222px;
							height:33px;
							border:1px solid #fff;
							border-radius: 10px;
							font-size:16px;
							line-height:33px;
							text-align: center;
						}
						.matterContent{
							display: flex;
							justify-content: space-between;
							margin-bottom:20px;
							div{
								width:226px;
								height:40px;
								line-height:40px;
								text-align: center;
								background:linear-gradient( #9929EA, #5808FB);
								font-size:18px;
								color:#fff;
								border-radius: 10px;
							}
						}
						.matterInfo{
							margin-bottom:20px;
							border:1px solid #fff;
							border-radius: 10px;
							padding:19px 40px;
							.text{
								font-size:16px;
								line-height:17px;
								margin-bottom:8px;
							}
							.num{
								font-size:30px;
								line-height: 25px;
								margin-bottom: 20px;
							}
							.item{
								display: flex;
								justify-content: space-between;
								font-size:16px;
								.status{
									color:#5808FB;
								}
							}
						}
						.cancelBtn{
							width:100%;
							height:51px;
							border-radius: 10px;
							background:#344B60;
							font-size:18px;
							color:#fff;
						}
						.disabledBtn{
							background: #999;
							:hover{
								cursor:not-allowed;
							}
						}
					}
					.rankingList{
						border-top: 1px solid #181B29;
						.top{
							display: flex;
							padding: 20px 10px;
							font-size:16px;
							line-height:17px;
							border-bottom: 1px solid #181B29;
							div{
								flex: 1;
								&:nth-child(1){
									text-align:left;
								}
								&:nth-child(3){
									text-align:right;
								}
							}
						}
						.rankingItem{
							display: flex;
							font-size:14px;
							line-height:13px;
							padding: 0px 10px;
							border-bottom: 1px solid #181B29;
							height:35px;
							line-height:35px;
							div{
								flex: 1;
								&:nth-child(1){
									text-align:left;
								}
								&:nth-child(3){
									text-align:right;
								}
							}
							img{
								width:24px;
								height:27px;
								vertical-align: middle;
							}
						}
					}
					.mattersList{
						border-top: 1px solid #181B29;
						padding: 20px 10px 0;
						.item{
							display: flex;
							justify-content: space-between;
							align-items: center;
							border:1px solid #fff;
							border-radius: 10px;
							padding:10px 20px;
							margin-bottom: 20px;
							:hover{
								cursor: pointer;
							}
							&:last-child {
								margin-bottom: 0;
							}
							.img img{
								width: 91px;
								height: 85px;
							}
							.label{
								font-size: 18px;
								line-height:19px;
								margin-bottom: 14px;
							}
							.day_num{
								font-size:24px;
								color:#E3283E;
								line-height:20px;
							}
							.time{
								font-size:20px;
								color:#344B60;
								line-height:20px;
							}
							.stage{
								.day{
									display: flex;
									justify-content: space-between;
									font-size:20px;
									color:#344B60;
									line-height:20px;
								}
							}
						}
					}
				}
			}
		}
		.myFlexs{
			position: fixed;
			right:10%;
			top: 85%;
			width:142px;
			height:123px;
			z-index: 1000000;
			opacity: .8;
			img{
				width:100%;
				height:100%;
			}
		}
	}
	.el-carousel__item{
		/*background-color: #272A3A!important;*/
	}
	.payBox input::-webkit-input-placeholder {
        color: #344B60;
    }
    .my-outbox{
        color: #fff;
        overflow: hidden;
        height: 35px;
        .my-inbox{
            white-space: nowrap;
            .my-list{
                margin-right: 25px;
                display: inline-block;
                font-size: 13px;
                height: 40px;
                line-height: 40px;
                .my-uname{
                    color: #FF8900;
                }
                span{
                    font-size: 30px;
                    font-weight:100;
                    vertical-align: middle;
                }
            }
        }
    }
    .noData{
    	text-align: center;
    	line-height: 511px;
    }
</style>