<template>
    <div class="mt45 bg-main">
        <img src="../assets/images/bgHotActive.png" alt="" class="w100 H500">
        <div class="w90 invite_container mauto zdx99 plr40 " style="margin-bottom: 30px;">
            <!-- 我的团队 -->
            <div style="padding:15px" class="kthy-content" v-if="showMyteam">
                <div style="width:100%;margin:7px auto 0;position: relative;">
                    <p style="text-align:center;color:#000;font-size:22px">活动奖励</p>

                    <!-- 我的团队列表 -->
                    <div style="width:100%;margin:20px auto 0;position: relative;color: #000;">
                        <table style="width:100%;border:none" cellpadding="0" cellspacing="0" class="myteam-table">
                            <thead>
                                <tr>
                                    <th>类型</th>
                                    <th>时间</th>
                                    <th>奖励</th>
                                    <th>已完成/总次数</th>
                                    <th>状态</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for = "(item,index) in pushList" :key="index">
                                    <td>{{item.type | statusName}}</td>
                                    <td>{{item.createTime | formatDate}}</td>
                                    <td>{{item.unReleaseAmount}}USDT</td>
                                    <td>{{item.hasTrade}}/{{item.needTrade}}</td>
                                    <td>{{(item.status === 0)?'未完成':'已完成'}}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
             <!-- 奖励规则 -->
            <div class="rewardRules">
                <div class="rewardTitle">
                    Libra赠金活动正式上线！
                </div>
                <div class="h1">尊敬的Libra用户：</div>
                <div class="h2">您好！为感谢新老客户对Libra长久以来对大力支持，Libra官方限时推出赠金活动!</div>
                <div>活动内容：</div>
                <div class="rewardInfo">
                    <div class="item">1.注册就送188USDT（需完成二级身份认证并进行合约交易达50手方可提现);</div>
                    <div class="item">2.首充2000USDT，赠送288USDT（需完成合约交易达80手方可提现;</div>
                    <div class="item">3.充值达5000USDT，赠送588USDT（需完成合约交易达150手方可提现）;</div>
                    <div class="item">4.充值达10000USDT，赠送1388USDT（需完成合约交易达300手方可提现）;</div>
                    <div class="item">5.完成大客户认证（充值及盈利使总资产达到100000USDT，即可申请成为大客户），赠送8888USDT（需完成合约交易达1500手方可提现）.</div>
                </div>
                <div>活动规则：</div>
                <div class="rewardInfo">
                    <div class="item">1.注册赠金与充值赠金不冲突，每位客户领取注册赠金后，可继续获得充值赠金；</div>
                    <div class="item">2.充值达到2000USDT、5000USDT、10000USDT后，将会按照阶梯获得补赠（例：已充值2000USDT获得288USDT赠金，再次充值3000USDT达到5000USDT后，将会补赠300USDT达到588USDT）；</div>
                    <div class="item">3.合约交易任务同上按照阶梯补增交易手数（例：充值2000USDT获得288USDT赠金后，完成10手合约交易，此时不可提现288USDT赠金；再次充值3000USDT，获得补赠300USDT后，同步将任务交易手数补增70手达到150手；此时您需要再交易140手，即达到150手合约交易方可提现588USDT）；</div>
                    <div class="item">4.完成合约交易1手，并非进行1次合约交易，每次合约交易您可以选择购买手数（例：每次交易购买100手，则您只需要3次合约交易即可解锁“充值达10000USDT，赠送1388USDT”，并提现1388USDT）。</div>
                </div>
                <div class="activeTime">活动时间：2020.5.20 00:00 ～ 2020.6.20 23:59（UTC+8）</div>
                <div class="tips"><span>备注：</span>充值赠送每天限定100名额，详情咨询客服或提交工单，及时领取奖励！</div>
                <div>最终解释权归Libra官方所有.</div>
            </div>
        </div>
    </div>
</template>
<script>
import "@/lib/clipboard.min.js";
export default {
    data(){
        return{
            token:'',
            rankList:[],
            inviteList:[],
            inviteList02:[],
            page:0,
            hasMore:false,
            limit:10,
            invite_code:'',
            c_name:'',
            c_rate:'',
            tab:1,
            msg:'',
            leverList:[
                {name:1,value:1},
                {name:2,value:2},
                {name:3,value:3}
            ],
            lever:'',
            account:'',
            count_inv:'', //总邀请返佣手续费
            count_release:'', //总邀请sgr返佣
            //我的团队
            userId:'',
            pushNumber:'',   //我的分享
            partnerNumber:'',   //团队合伙人数量
            sumMoney:'',   //累计奖励
            pushList:[],  //直推用户集合
            awardDetail:[],  //直推用户集合
            showMyteam:true  //显示我的团队
            //我的团队结束
        }
    },
    filters:{
        formatDate(nS) {
            let date = new Date(nS);
            let y = date.getFullYear();
            let MM = date.getMonth() + 1;
            MM = MM < 10 ? ('0' + MM) : MM;
            let d = date.getDate();
            d = d < 10 ? ('0' + d) : d;
            let h = date.getHours();
            h = h < 10 ? ('0' + h) : h;
            let m = date.getMinutes();
            m = m < 10 ? ('0' + m) : m;
            let s = date.getSeconds();
            s = s < 10 ? ('0' + s) : s;
            return y + '-' + MM + '-' + d + ' ' + h + ':' + m + ':' + s;
        },
        statusName(status) {
            let statusList = [
                '充值',
                '法币',
                '实名认证'
            ]
            return statusList[status]
        }
    },
    created(){
        this.token=localStorage.getItem('token')||'';
        // this.init();
        // this.userInfo();
        // this.getRate();
        // this.getInviteAccount();
        // this.inviteLog();
        // this.inviteUser();
        // this.getCount();
        this.selectmyTeam();  //我的团队
    },
    methods:{
        // 去往奖励明细
        goMinxi(){
           this.showMyteam = false
        },
        //返货我的团队
        goBack(){
           this.showMyteam = true
        },
        // 我的团队查看
        selectmyTeam(){
            let that = this
            this.token=localStorage.getItem('token')||'';
            this.userId=localStorage.getItem('userId')||'';
            this.$http({
                url: '/api/release/list?userId=' + this.userId,
                methods: 'post',
                headers:{Authorization:this.token}
            }).then(res => {
                if(res.data.type == 'ok'){
                    this.pushList = res.data.message
                }
            })
            // this.$http({
            //     url:'/api/userpartnerlevel/findUserTeam',
            //     method:'post',
            //     data:{
            //         userId:this.userId
            //     },
            //     headers:{Authorization:this.token}
            // }).then(res=>{
            //     if(res.data.type == 'ok'){
            //         that.pushNumber = res.data.message.pushNumber
            //         that.partnerNumber = res.data.message.partnerNumber
            //         that.sumMoney = res.data.message.sumMoney
            //         that.pushList = res.data.message.pushList
            //         that.awardDetail = res.data.message.awardDetail
            //     }else{
            //         this.$layer.msg(res.data.message)
            //     }
            // })
        },
        //总返佣

        getCount(){
            this.$http({
                url:'/api/user/invite_user_count',
                method:'get',
                headers:{Authorization:this.token}
            }).then(res=>{
                if(res.data.type == 'ok'){
                    this.count_inv = res.data.message.count_inv;
                    this.count_release = res.data.message.count_release;
                }
            })
        },
        getInviteAccount(){
            this.$http({
                url:'/api/user/invite_count',
                method:'get',
                headers:{Authorization:this.token}
            }).then(res=>{
                if(res.data.type == 'ok'){
                    this.msg = res.data.message;
                }
            })
        },
        getRate(){
            this.$http({
                url:'/api/wallet/get_info',
                method:'post',
                headers:{Authorization:this.token}
            }).then(res=>{
                if(res.data.type == 'ok'){
                    this.c_name = res.data.message.c_name;
                    this.c_rate = res.data.message.c_rate;
                }
            })
        },
        userInfo(){
           this.$http({
            url: "/api/" + "user/info",
            method: "get",
            data: {},
            headers: { Authorization: localStorage.getItem("token") }
        }).then(res => {
            if (res.data.type == "ok") {
               this.invite_code = res.data.message.invite_code
            }
            })
        },
        //复制
        copy() {
            var that = this;
            var clipboard = new Clipboard("#copy", {
                text: function() {
                return (
                    that.invite_code
                );
                }
            });
            clipboard.on("success", function(e) {
                that.flags = true;
                layer.msg(that.$t('lay.copys'));
            });
            clipboard.on("error", function(e) {
                that.flags = false;
                layer.msg(that.$t('lay.recopy'));
            });
            },

        copy_link(){
            var that = this;
            var clipboard = new Clipboard(".copy_link", {
                text: function() {
                return (
                    'http://www.libra.com/#/components/register?code='+that.invite_code
                );
                }
            });
            clipboard.on("success", function(e) {
                that.flags = true;
                layer.msg(that.$t('lay.copys'));
            });
            clipboard.on("error", function(e) {
                that.flags = false;
                layer.msg(that.$t('lay.recopy'));
            });
            },


    }
}
</script>
<style lang='scss'>
.rewardRules{
    margin-top:20px;
    background: rgb(224, 242, 255);
    padding: 20px 30px;
}
.activeTime{
    margin-top:20px;
}
.rewardTitle{
    font-size: 20px;
    margin-bottom:10px;
}
.rewardRules .item{
    line-height:20px;
    margin-left: 20px;
}
.tips span{
    color:red;
}
.H500{
    height: 500px;
}
.H34{
    height: 34px;
}
.invite_container{
    max-width: 1200px;
    margin-top: 30px;
    position: relative;
    .invite_header{
        height: 268px;
        .head{
            height: 64px;
        }
    }
}
.shadows{
    box-shadow: 0 0 8px #eee;
}

.kthy-content {
    background-color: #fff;
    color: #fff;

}
.kthy-header{
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
    margin: 0 auto;
    padding: 20px 10px;
    background-color: #09273F;
}

.myteam-table th{
    padding: 5px;
    text-align: center;
    color:#5D6E84
}

.myteam-table tbody td{
    padding: 5px;
    text-align: center
}

</style>

