<template>
	<div class="noticeDetail clr-part bg-part">
		<div style="height: 12px ; background-color: rgba(242,246,250,.5) !important;">

		</div>
		<div class="notice-info">
			<div class="content-box">
				<div class="content-text c-4-bg"><h1 class="content-title tc f-1-cl">{{title}}</h1>
					<!--						<p class="time f-2-cl">2019/07/12 21:39:35</p>-->
					<div class="main-text f-2-cl">
						<!--							<p>尊敬的用户，</p>-->

						<p v-html="content" ref="con"></p>

						<p>&nbsp;</p>

						<p>&nbsp;</p>

						<p>{{abstract}}</p>

						<p>{{create_time}}</p></div>
				</div>
			</div>
			<!-- <div class="moredetail ft12 " style="width: 100px; height: 10px; color: #828ea1"><router-link :to="{path:'/noticeHelp'}" tag="span">查看更多...</router-link></div>
				 -->
		</div>
	</div>
</template>
<script>
	import indexHeader from '@/view/indexHeader'

	export default {
		name: 'noticeDetail',
		components: {indexHeader},
		data() {
			return {
				title: '',
				content: '',
				abstract: '',
				create_time: '',
				newList: [],
			}
		},
		created() {
			this.id = this.$route.query.id;
			var locale = window.localStorage.getItem('locale');
			var id = this.id;
			this.getData();
		},
		mounted() {

			var that = this;
			that.getNotice();
			// var tags=this.$refs.con.getElementsByTagName('p');
			// //console.log(tags)
			// for(var i=0;i<tags.length;i++){
			//     //console.log(tags)
			//     //console.log(tags[i])
			//     tags[i].style.background='transparent'
			// }
		},
		watch: {
			$route() {
				if (this.$route.query.id != this.id) {
					this.id = this.$route.query.id;
					this.$nextTick(() => {
						this.getData();
					})
				}
			}
		},
		methods: {
			/*handleSizeChange(val) {
				//console.log(`每页 ${val} 条`);
			},
			handleCurrentChange(val) {
				//console.log(`当前页: ${val}`);
			},*/
			getNotice() {
				this.$http({
					url: '/api/news/list',
					method: 'get',
					data: {language: this.$i18n.locale == 'zh' ? 1 : 2}
				}).then(res => {
					var that = this;
					// //console.log(res);
					this.newList = res.data.message.list
					// this.is_active = this.newList[0].thisid
					$.each(this.newList, function (k, v) {
						v.time = that.timestampToTime(v.time);
					})
				})
			},

			goBefore() {
				this.$router.back(-1);
			},
			getData() {
				this.$http({
					url: '/fastnews/' + this.id,
					method: 'get',
					headers: {'Authorization': window.localStorage.getItem('token')}
				}).then(res => {
					res = res.data;
					if (res.type === 'ok') {
						//console.log('uuuuu')
						//console.log(res.message)
						this.title = res.message.title;
						this.content = res.message.content;
						this.abstract = res.message.abstract;
						let time = res.message.publishTime;
						// //console.log(res.message.update_time, time)
						this.create_time= this.timestampToTime(time);

						// this.setProperty(this.timestampToTime(res.message.update_time));
						//console.log('ppp')
					} else {
						layer.msg(res.message);
					}
				}).catch(error => {
					//console.log(error)
				})
			},
			//    setProperty(){
			//         var tags=document.getElementsByTagName('p');
			//         HTMLCollection.prototype.forEach=function(callback){
			//                 [].slice.call(this).forEach(callback);
			//         };
			//         tags.forEach(function(e, i){
			//                 e.style.backgroundColor='#666 !important'
			//         });


			//    },

			timestampToTime(timestamp) {
				var date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
				var Y = date.getFullYear() + '-';
				var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
				var D = this.change(date.getDate()) + ' ';
				var h = this.change(date.getHours()) + ':';
				var m = this.change(date.getMinutes()) + ':';
				var s = this.change(date.getSeconds());
				return Y + M + D;
			},
			change(t) {
				if (t < 10) {
					return "0" + t;
				} else {
					return t;
				}
			}
		}
	}
</script>
<style lang="scss" scoped>
	.hand_active {
		background: white !important;
		color: rgba(130, 142, 161, 1) !important;
	}

	.title {
		font-size: 20px;
		font-weight: bold;
	}

	.f-2-cl {
		color: rgba(130, 142, 161, 1) !important;
	}

	.c-4-bg {
		background-color: rgba(255, 255, 255, 1) !important;
	}

	.noticeDetail {
		background-color: rgba(242, 246, 250, .5) !important;

		.notice-info {
			// background: url(../assets/images/account_center_bg.jpg) no-repeat;
			// background-size: cover;3


			.main-content {
				width: 1180px;
				margin: 120px auto 0;
			}

			.content-text {
				min-height: 680px;
				padding: 40px 60px 60px;
				position: relative;
				border-radius: 2px;
			}

			.menu {
				width: 190px;
				float: left;

				.menu-tit {
					font-size: 16px;
					line-height: 32px;
					margin-bottom: 17px;
					font-weight: 400;
					color: rgba(49, 54, 62, 1) !important;
				}

				.menu-item {
					padding: 15px 25px 15px 20px;
					font-size: 14px;
					line-height: 20px;
					cursor: pointer;
					/*-webkit-user-select: none;
					-moz-user-select: none;
					-ms-user-select: none;*/
					user-select: none;
					border-radius: 2px;
				}

				.pagination {
					background: none !important;
					border: none !important;
					border-radius: 0 0 2px 2px;

				}

				.pagination-bar {
					border: none !important;
					line-height: 50px;
				}
			}

			.content-box {
				width: 1200px;
				margin: 60px auto 20px;
			}
			.moredetail {

					cursor: pointer;

				 span:hover {
					color: #357ce1;
				}
			}

			.account {
				width: 1200px;
				margin: 0 auto;
				padding-top: 30px;
				overflow: hidden;
				min-height: 880px;

				.nav-after {
					display: block;
					height: 10px;
					// background-color: #262a42;
				}

				.account-content {
					width: 100%;
					min-height: 750px;
					// background-color: #181b2a;
					.detailBig {
						padding: 0px 46px 20px;

						.mb30 {
							margin-bottom: 30px;
						}

						.detailContent {
							line-height: 26px;

							p {
								& > * {
									// background-color: #181b2a!important;
								}
							}

						}

						.mt5 {
							margin-top: 5px;
						}
					}

				}

			}
		}
	}
</style>



